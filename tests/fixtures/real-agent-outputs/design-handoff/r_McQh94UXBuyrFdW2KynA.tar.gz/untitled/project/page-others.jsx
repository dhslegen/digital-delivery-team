/* global React, Icon, PageShell */
// ============================================================
// 其他页面：任务/告警/事故/基础信息/系统配置/日志
// ============================================================

const { useState: useS, useEffect: useE, useMemo: useM, useRef: useR } = React;

// ============================================================
// 通用：表格工具栏 / 筛选栏
// ============================================================
function Toolbar({ left, right }) {
  return (
    <div className="toolbar">
      <div className="row gap-2 flex1">{left}</div>
      <div className="row gap-2">{right}</div>
    </div>
  );
}

// ============================================================
// PAGE: 任务记录
// ============================================================
const TASKS = [
  { id: "T-2026-0428-1182", v: "JD-X07-118", route: "R-04 · 亚一仓→南区分拨", client: "京东物流·华东", status: "运输中",  progress: 0.62, dispatch: "10:02:14", planned: "11:18", waybills: 8,  alerts: 1 },
  { id: "T-2026-0428-1181", v: "JD-X07-204", route: "R-02 · 北门枢纽→东塔配送站", client: "京东物流·华东", status: "运输中",  progress: 0.81, dispatch: "10:01:08", planned: "11:05", waybills: 12, alerts: 0 },
  { id: "T-2026-0428-1180", v: "JD-X07-009", route: "R-15 · 南区分拨→运河支线", client: "城北小件中心", status: "异常",    progress: 0.34, dispatch: "09:54:52", planned: "11:38", waybills: 6,  alerts: 2 },
  { id: "T-2026-0428-1179", v: "JD-X07-077", route: "—",                     client: "—",            status: "充电中",  progress: 0,    dispatch: "—",        planned: "—",     waybills: 0, alerts: 1 },
  { id: "T-2026-0428-1178", v: "JD-X07-225", route: "R-02 · 北门枢纽→东塔配送站", client: "京东物流·华东", status: "已完成",  progress: 1,    dispatch: "08:14:00", planned: "09:42", waybills: 12, alerts: 0 },
  { id: "T-2026-0428-1177", v: "JD-X07-156", route: "R-08 · 亚一仓→城北小件中心", client: "顺丰速运",     status: "运输中",  progress: 0.45, dispatch: "09:42:18", planned: "11:12", waybills: 9,  alerts: 1 },
  { id: "T-2026-0428-1176", v: "JD-X07-340", route: "R-04 · 亚一仓→南区分拨",   client: "京东物流·华东", status: "运输中",  progress: 0.71, dispatch: "09:38:30", planned: "10:54", waybills: 7,  alerts: 0 },
  { id: "T-2026-0428-1175", v: "JD-X07-091", route: "—",                       client: "—",            status: "空闲",    progress: 0,    dispatch: "—",        planned: "—",     waybills: 0, alerts: 0 },
  { id: "T-2026-0428-1174", v: "JD-X07-312", route: "R-11 · 亚一仓→运河支线",   client: "中通南方分拨",  status: "已完成",  progress: 1,    dispatch: "07:52:00", planned: "09:15", waybills: 11, alerts: 0 },
];

const TASK_DETAIL = {
  id: "T-2026-0428-1180",
  v: "JD-X07-009",
  status: "异常",
  events: [
    { t: "09:54:52", icon: "play",   tone: "info", title: "任务派发", desc: "由调度员 沈知行 创建并派发" },
    { t: "09:55:01", icon: "check",  tone: "ok",   title: "车辆接单", desc: "JD-X07-009 远程激活，自检通过" },
    { t: "09:57:10", icon: "vehicle", tone: "info", title: "驶离 南区分拨", desc: "出场闸口 G3，载重 54%" },
    { t: "10:09:42", icon: "alert",  tone: "warn", title: "前方障碍物，规避绕行", desc: "持续时间 8.4s，绕行 12m" },
    { t: "10:18:44", icon: "alert",  tone: "warn", title: "偏离规划路线 12m", desc: "已派发：处置员 吴桐" },
    { t: "10:24:18", icon: "zap",    tone: "err",  title: "电量过低告警 18%", desc: "建议：就近 西区充电场，预计 6 分钟到达" },
    { t: "10:24:30", icon: "more",   tone: "muted", title: "等待处置...",     desc: "" },
  ],
};

function TaskProgress({ p, status }) {
  const tone = status === "异常" ? "err" : status === "已完成" ? "ok" : status === "充电中" ? "info" : status === "空闲" ? "muted" : "brand";
  const colorMap = { brand: "var(--brand-400)", ok: "var(--ok)", warn: "var(--warn)", err: "var(--err)", info: "var(--data-blue)", muted: "var(--text-3)" };
  return (
    <div className="tprog">
      <div className="tprog-bar">
        <div className="tprog-fill" style={{ width: `${p*100}%`, background: colorMap[tone], boxShadow: `0 0 6px ${colorMap[tone]}` }}/>
      </div>
      <span className="mono t3" style={{fontSize:11, width:36}}>{Math.round(p*100)}%</span>
    </div>
  );
}

function TasksPage() {
  return (
    <PageShell active="tasks" title="任务记录" breadcrumb={["运营", "任务记录"]}
      topRight={<>
        <button className="btn"><Icon name="upload" size={13}/>导出</button>
        <button className="btn primary"><Icon name="plus" size={13}/>新建任务</button>
      </>}>
      <div className="task-page">
        {/* 顶部 stat 条 */}
        <div className="stat-strip">
          <div className="stat-cell"><span className="t3">今日任务</span><span className="kpi-value" style={{fontSize:20}}>6,420</span></div>
          <div className="stat-cell"><span className="t3">运输中</span><span className="kpi-value tx" style={{fontSize:20}}>824</span></div>
          <div className="stat-cell"><span className="t3">已完成</span><span className="kpi-value tg" style={{fontSize:20}}>5,187</span></div>
          <div className="stat-cell"><span className="t3">异常</span><span className="kpi-value tr" style={{fontSize:20}}>11</span></div>
          <div className="stat-cell"><span className="t3">平均时长</span><span className="kpi-value" style={{fontSize:20}}>72<span style={{fontSize:12}}>min</span></span></div>
          <div className="stat-cell"><span className="t3">准点率</span><span className="kpi-value tg" style={{fontSize:20}}>96.4<span style={{fontSize:12}}>%</span></span></div>
        </div>

        <div className="task-split">
          {/* 左：表格 */}
          <div className="card flex1" style={{display:'flex',flexDirection:'column',minWidth:0}}>
            <Toolbar
              left={<>
                <div className="row gap-2" style={{position:'relative'}}>
                  <Icon name="search" size={13} style={{position:'absolute',left:8,top:7,color:'var(--text-3)'}}/>
                  <input className="input" placeholder="任务号 / 车牌 / 客户" style={{paddingLeft:28, width:240}}/>
                </div>
                <button className="btn sm">今日 ▾</button>
                <button className="btn sm">客户 ▾</button>
                <button className="btn sm">网点 ▾</button>
                <button className="btn sm active-filter">状态：运输中 ×</button>
              </>}
              right={<>
                <span className="t3 mono" style={{fontSize:11}}>共 <span className="t1">1,284</span> 条</span>
                <button className="btn sm"><Icon name="filter" size={11}/>更多筛选</button>
              </>}/>
            <div style={{overflow:'auto', flex: 1}}>
              <table className="table">
                <thead><tr>
                  <th style={{width:32}}><input type="checkbox"/></th>
                  <th>任务号</th>
                  <th>车牌</th>
                  <th style={{width:'25%'}}>路线 / 客户</th>
                  <th>状态</th>
                  <th style={{width:160}}>进度</th>
                  <th>派单时刻</th>
                  <th>计划完成</th>
                  <th>运单</th>
                  <th>告警</th>
                  <th></th>
                </tr></thead>
                <tbody>
                  {TASKS.map((t,i) => (
                    <tr key={t.id} className={t.id === TASK_DETAIL.id ? "row-active" : ""}>
                      <td><input type="checkbox"/></td>
                      <td className="mono t2" style={{fontSize:11}}>{t.id}</td>
                      <td className="mono fw6">{t.v}</td>
                      <td>
                        <div className="t1">{t.route}</div>
                        <div className="t3" style={{fontSize:11}}>{t.client}</div>
                      </td>
                      <td>
                        <span className={`pill ${t.status === '异常' ? 'err' : t.status === '已完成' ? 'ok' : t.status === '空闲' ? 'muted' : t.status === '充电中' ? 'info' : 'ok'}`}>
                          <span className="dot"/>{t.status}
                        </span>
                      </td>
                      <td><TaskProgress p={t.progress} status={t.status}/></td>
                      <td className="mono t2">{t.dispatch}</td>
                      <td className="mono t2">{t.planned}</td>
                      <td className="mono">{t.waybills}</td>
                      <td>{t.alerts > 0 ? <span className="pill err"><span className="dot"/>{t.alerts}</span> : <span className="t3">—</span>}</td>
                      <td><button className="btn sm ghost"><Icon name="more" size={13}/></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <div className="pager">
              <span className="t3" style={{fontSize:11}}>显示 1–9 / 共 1,284</span>
              <div className="row gap-1">
                <button className="btn sm"><Icon name="chevl" size={11}/></button>
                <button className="btn sm primary">1</button>
                <button className="btn sm">2</button>
                <button className="btn sm">3</button>
                <span className="t3">...</span>
                <button className="btn sm">143</button>
                <button className="btn sm"><Icon name="chevr" size={11}/></button>
              </div>
            </div>
          </div>

          {/* 右：任务详情 */}
          <div className="card task-detail">
            <div className="card-header">
              <div className="col">
                <span className="t3 mono" style={{fontSize:10}}>{TASK_DETAIL.id}</span>
                <span className="fw6" style={{fontSize:14, color:'var(--text-1)', marginTop:2}}>任务详情 · <span className="mono">{TASK_DETAIL.v}</span></span>
              </div>
              <span className="pill err"><span className="dot"/>异常进行中</span>
            </div>

            <div className="td-meta">
              <div className="row gap-3 wrap">
                <div className="meta-cell"><span className="t3">客户</span><span>城北小件中心</span></div>
                <div className="meta-cell"><span className="t3">起点</span><span>南区分拨</span></div>
                <div className="meta-cell"><span className="t3">终点</span><span>运河支线</span></div>
                <div className="meta-cell"><span className="t3">运单数</span><span className="mono">6</span></div>
                <div className="meta-cell"><span className="t3">指派员</span><span>沈知行</span></div>
                <div className="meta-cell"><span className="t3">处置员</span><span>吴桐</span></div>
              </div>
            </div>

            {/* 路径示意 */}
            <div className="td-route">
              <svg viewBox="0 0 320 64" style={{width:'100%',height:64}}>
                <path d="M 16 32 Q 80 10, 160 32 T 304 32" fill="none" stroke="var(--bg-3)" strokeWidth="3"/>
                <path d="M 16 32 Q 80 10, 160 32" fill="none" stroke="var(--err)" strokeWidth="2.5"/>
                <circle cx="16" cy="32" r="6" fill="var(--ok)" stroke="#001428" strokeWidth="2"/>
                <circle cx="160" cy="32" r="7" fill="var(--err)" stroke="#001428" strokeWidth="2">
                  <animate attributeName="r" values="7;9;7" dur="1.4s" repeatCount="indefinite"/>
                </circle>
                <circle cx="304" cy="32" r="6" fill="var(--bg-4)" stroke="var(--text-3)" strokeWidth="2"/>
                <text x="16" y="56" textAnchor="middle" fontSize="10" fill="var(--text-3)">起点</text>
                <text x="160" y="56" textAnchor="middle" fontSize="10" fill="var(--err)">当前 · 异常</text>
                <text x="304" y="56" textAnchor="middle" fontSize="10" fill="var(--text-3)">终点</text>
              </svg>
            </div>

            <div className="td-tabs">
              <button className="td-tab active">运单日志 · 7</button>
              <button className="td-tab">关键事件</button>
              <button className="td-tab">告警记录 · 2</button>
              <button className="td-tab">规划路线</button>
            </div>

            <div className="td-events">
              {TASK_DETAIL.events.map((e,i) => (
                <div key={i} className={`tev tone-${e.tone}`}>
                  <div className="tev-rail">
                    <div className="tev-icon"><Icon name={e.icon} size={12}/></div>
                    {i < TASK_DETAIL.events.length - 1 && <div className="tev-line"/>}
                  </div>
                  <div className="col flex1" style={{paddingBottom: 14}}>
                    <div className="row between">
                      <span className="fw6" style={{fontSize:12.5}}>{e.title}</span>
                      <span className="mono t3" style={{fontSize:10}}>{e.t}</span>
                    </div>
                    {e.desc && <span className="t2" style={{fontSize:11.5, marginTop:2}}>{e.desc}</span>}
                  </div>
                </div>
              ))}
            </div>

            <div className="td-actions">
              <button className="btn">远程接管</button>
              <button className="btn">查看 3D</button>
              <button className="btn primary"><Icon name="zap" size={13}/>处置告警</button>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 告警处置工作流 (端到端闭环)
// ============================================================
const ALERT_QUEUE = [
  { id: "AL-2026-0428-007", level: "err",  type: "电量过低 18%",   v: "JD-X07-009", t: "10:24:18", site: "南区分拨",  state: "待处置", sla: 60 },
  { id: "AL-2026-0428-006", level: "err",  type: "急刹动作触发",   v: "JD-X07-156", t: "10:21:02", site: "亚一中心仓", state: "待处置", sla: 240 },
  { id: "AL-2026-0428-005", level: "warn", type: "偏离路线 12m",   v: "JD-X07-118", t: "10:18:44", site: "亚一中心仓", state: "已派单 · 吴桐", sla: 600 },
  { id: "AL-2026-0428-004", level: "warn", type: "障碍物滞留 8s",   v: "JD-X07-225", t: "10:14:37", site: "亚一中心仓", state: "处置中 · 周野", sla: 1080 },
  { id: "AL-2026-0428-003", level: "warn", type: "充电功率异常",   v: "JD-X07-077", t: "10:09:55", site: "西区充电场", state: "处置中 · 林夕", sla: 1380 },
];

function fmtSec(s) {
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s/60)}min`;
  return `${Math.floor(s/3600)}h`;
}

function AlertsPage() {
  const [sel, setSel] = useS(0);
  const a = ALERT_QUEUE[sel];
  const stages = ["接收","派发","定位","处置","复核","归档"];
  const stageNow = a.state.startsWith("处置中") ? 3 : a.state.startsWith("已派单") ? 1 : 0;

  return (
    <PageShell active="alerts" title="告警处置" breadcrumb={["运营", "告警处置"]}
      topRight={<>
        <span className="pill err"><span className="dot"/>未处置 7 · 超时 2</span>
        <button className="btn"><Icon name="history" size={13}/>历史告警</button>
      </>}>
      <div className="alert-page">
        {/* 顶部告警节奏图 */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">告警态势 · 近 24 小时</span>
            <div className="row gap-3">
              <span className="pill err"><span className="dot"/>严重 7</span>
              <span className="pill warn"><span className="dot"/>警告 14</span>
              <span className="pill info"><span className="dot"/>提示 12</span>
            </div>
          </div>
          <div style={{padding:'14px 18px', height: 130, position: 'relative'}}>
            <AlertHeat/>
          </div>
        </div>

        <div className="alert-grid">
          {/* 左：队列 */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">告警队列 · 5</span>
              <div className="row gap-2">
                <button className="btn sm">全部</button>
                <button className="btn sm primary">未处置</button>
              </div>
            </div>
            <div className="aq-list">
              {ALERT_QUEUE.map((q, i) => (
                <div key={q.id} className={"aq-item " + (i === sel ? "active" : "")} onClick={() => setSel(i)}>
                  <div className={`aq-bar tone-${q.level}`}/>
                  <div className="col flex1" style={{minWidth:0}}>
                    <div className="row between">
                      <span className="mono t3" style={{fontSize:10}}>{q.id}</span>
                      <span className="mono t3" style={{fontSize:10}}>{q.t}</span>
                    </div>
                    <div className="row gap-2 between" style={{marginTop:3}}>
                      <span className="fw6" style={{fontSize:12.5}}>{q.type}</span>
                    </div>
                    <div className="row between" style={{marginTop:2}}>
                      <span className="mono t2" style={{fontSize:11}}>{q.v}</span>
                      <span className="t3" style={{fontSize:11}}>{q.site}</span>
                    </div>
                    <div className="row between" style={{marginTop:5}}>
                      <span className={`pill ${q.state.includes('处置中') ? 'warn' : q.state.includes('已派单') ? 'info' : 'err'}`}>
                        <span className="dot"/>{q.state}
                      </span>
                      <span className="mono t3" style={{fontSize:10}}>SLA {fmtSec(q.sla)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 右：处置工作流 */}
          <div className="card alert-detail">
            <div className="card-header">
              <div className="col">
                <span className="t3 mono" style={{fontSize:10}}>{a.id}</span>
                <span className="fw6" style={{fontSize:15, marginTop:2}}>{a.type} · <span className="mono tx">{a.v}</span></span>
              </div>
              <div className="row gap-2">
                <button className="btn sm">忽略</button>
                <button className="btn sm">转派</button>
                <button className="btn primary"><Icon name="check" size={13}/>开始处置</button>
              </div>
            </div>

            {/* 工作流步骤 */}
            <div className="wf-stages">
              {stages.map((s, i) => (
                <div key={s} className={"wf-stage " + (i < stageNow ? "done" : i === stageNow ? "current" : "")}>
                  <div className="wf-num">
                    {i < stageNow ? <Icon name="check" size={11}/> : i + 1}
                  </div>
                  <div className="wf-label">{s}</div>
                  {i < stages.length - 1 && <div className="wf-line"/>}
                </div>
              ))}
            </div>

            <div className="alert-2col">
              {/* 上下文 */}
              <div className="ad-block">
                <div className="ad-block-title">告警上下文</div>
                <div className="kv">
                  <div><span className="t3">触发时间</span><span className="mono">2026-04-28 10:24:18</span></div>
                  <div><span className="t3">告警类型</span><span>电量过低 (BAT_LOW)</span></div>
                  <div><span className="t3">阈值</span><span className="mono">≤ 20% (实际 18%)</span></div>
                  <div><span className="t3">车辆</span><span className="mono">JD-X07-009</span></div>
                  <div><span className="t3">所属客户</span><span>城北小件中心</span></div>
                  <div><span className="t3">网点</span><span>南区分拨</span></div>
                  <div><span className="t3">关联任务</span><span className="mono tx">T-2026-0428-1180</span></div>
                  <div><span className="t3">载重</span><span className="mono">54%</span></div>
                  <div><span className="t3">速度</span><span className="mono">12 km/h</span></div>
                  <div><span className="t3">坐标</span><span className="mono" style={{fontSize:11}}>31.1942, 121.6174</span></div>
                </div>
              </div>

              {/* 智能建议 */}
              <div className="ad-block">
                <div className="ad-block-title">
                  <Icon name="zap" size={12} style={{color:'var(--data-violet)',marginRight:4,verticalAlign:-1}}/>
                  AI 处置建议
                </div>
                <div className="suggestion">
                  <div className="sug-card primary">
                    <div className="row between">
                      <span className="fw6" style={{fontSize:12}}>方案 A · 就近充电</span>
                      <span className="mono tg" style={{fontSize:11}}>推荐</span>
                    </div>
                    <div className="t2" style={{fontSize:11.5, marginTop:4}}>
                      调度至 <span className="t1 fw6">西区充电场</span>，预计 <span className="mono tx">6 分钟</span>到达，剩余电量足以完成。
                    </div>
                    <div className="row gap-2" style={{marginTop:8}}>
                      <button className="btn primary sm">采纳并执行</button>
                      <button className="btn sm">查看路径</button>
                    </div>
                  </div>
                  <div className="sug-card">
                    <div className="row between">
                      <span className="fw6" style={{fontSize:12}}>方案 B · 替换车辆</span>
                      <span className="t3" style={{fontSize:11}}>影响 1 任务</span>
                    </div>
                    <div className="t2" style={{fontSize:11.5, marginTop:4}}>
                      由 <span className="t1 fw6">JD-X07-091 (空闲, 91%)</span> 接管，原车回场。
                    </div>
                  </div>
                  <div className="sug-card">
                    <div className="row between">
                      <span className="fw6" style={{fontSize:12}}>方案 C · 远程接管</span>
                      <span className="t3" style={{fontSize:11}}>需值班司机</span>
                    </div>
                    <div className="t2" style={{fontSize:11.5, marginTop:4}}>
                      由远程驾驶员手动操控至最近充电桩。
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* 处置流水 */}
            <div className="ad-block" style={{borderTop:'1px solid var(--line-1)'}}>
              <div className="ad-block-title">处置流水</div>
              <div className="dispatch-log">
                <div className="dl-row"><span className="mono t3">10:24:18</span><span className="pill err"><span className="dot"/>触发</span><span className="t2">系统检测电量低于阈值，自动入队</span></div>
                <div className="dl-row"><span className="mono t3">10:24:24</span><span className="pill info"><span className="dot"/>通知</span><span className="t2">推送至当班调度组（4 人）</span></div>
                <div className="dl-row"><span className="mono t3">10:24:42</span><span className="pill warn"><span className="dot"/>认领</span><span className="t2">沈知行 认领并冻结车辆任务</span></div>
                <div className="dl-row" style={{opacity:.5}}><span className="mono t3">--:--:--</span><span className="pill muted"><span className="dot"/>待处置</span><span className="t2">等待调度方案下发...</span></div>
              </div>
              <div className="row gap-2" style={{marginTop:10}}>
                <input className="input flex1" placeholder="添加处置备注 (将记入审计日志)..."/>
                <button className="btn">添加附件</button>
                <button className="btn primary">完成处置</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

function AlertHeat() {
  const data = Array.from({length: 24}, (_, h) => ({
    h, err: Math.round(Math.random() * 4 + (h > 8 && h < 11 ? 4 : 0)),
    warn: Math.round(Math.random() * 6 + 2),
    info: Math.round(Math.random() * 4 + 1),
  }));
  const max = Math.max(...data.map(d => d.err + d.warn + d.info));
  return (
    <div style={{display:'flex', alignItems:'flex-end', gap:6, height:'100%'}}>
      {data.map((d, i) => {
        const total = d.err + d.warn + d.info;
        const h = (total / max) * 100;
        return (
          <div key={i} style={{flex:1, height:'100%', display:'flex', flexDirection:'column', justifyContent:'flex-end', alignItems:'center', gap:4}}>
            <div style={{width:'100%', height:`${h}%`, display:'flex',flexDirection:'column-reverse',borderRadius:3,overflow:'hidden'}}>
              <div style={{height:`${d.err/total*100}%`, background:'var(--err)', boxShadow:'0 0 6px var(--err)'}}/>
              <div style={{height:`${d.warn/total*100}%`, background:'var(--warn)'}}/>
              <div style={{height:`${d.info/total*100}%`, background:'var(--info)', opacity: 0.6}}/>
            </div>
            <span className="mono t3" style={{fontSize:9}}>{String(i).padStart(2,'0')}</span>
          </div>
        );
      })}
    </div>
  );
}

// ============================================================
// PAGE: 事故管理
// ============================================================
const ACCIDENTS = [
  { id: "ACC-2026-0411-002", t: "2026-04-11 14:32", site: "亚一中心仓 · G2 闸口", v: "JD-X07-118", level: "轻微", liability: "对方全责", status: "已结案",   reporter: "沈知行", files: 5 },
  { id: "ACC-2026-0408-001", t: "2026-04-08 09:18", site: "南区分拨 · 出口斜坡",  v: "JD-X07-009", level: "一般", liability: "我方主责", status: "理赔中",   reporter: "吴桐",   files: 8 },
  { id: "ACC-2026-0327-003", t: "2026-03-27 23:51", site: "西区充电场",            v: "JD-X07-077", level: "未遂", liability: "无责任",   status: "已结案",   reporter: "林夕",   files: 3 },
  { id: "ACC-2026-0319-002", t: "2026-03-19 11:04", site: "运河支线 K2+300",       v: "JD-X07-312", level: "一般", liability: "对方主责", status: "调查中",   reporter: "周野",   files: 6 },
];

function AccidentPage() {
  return (
    <PageShell active="accident" title="事故管理" breadcrumb={["运营", "事故管理"]}
      topRight={<>
        <button className="btn"><Icon name="upload" size={13}/>导出报告</button>
        <button className="btn primary"><Icon name="plus" size={13}/>登记事故</button>
      </>}>
      <div className="acc-page">
        <div className="stat-strip">
          <div className="stat-cell"><span className="t3">本年累计</span><span className="kpi-value" style={{fontSize:20}}>7</span></div>
          <div className="stat-cell"><span className="t3">未结案</span><span className="kpi-value tw" style={{fontSize:20}}>2</span></div>
          <div className="stat-cell"><span className="t3">百万公里事故率</span><span className="kpi-value tg" style={{fontSize:20}}>0.024</span></div>
          <div className="stat-cell"><span className="t3">同比</span><span className="kpi-value tg" style={{fontSize:20}}>↓ 38%</span></div>
          <div className="stat-cell"><span className="t3">理赔金额（YTD）</span><span className="kpi-value" style={{fontSize:20}}>¥ 28,400</span></div>
        </div>

        <div className="acc-grid">
          {/* 左：列表 */}
          <div className="card flex1" style={{display:'flex',flexDirection:'column',minWidth:0}}>
            <Toolbar
              left={<>
                <input className="input" placeholder="事故编号 / 车牌 / 地点" style={{width:240}}/>
                <button className="btn sm">本年 ▾</button>
                <button className="btn sm">等级 ▾</button>
                <button className="btn sm">责任划分 ▾</button>
              </>}
              right={<span className="t3 mono" style={{fontSize:11}}>共 7 条</span>}/>
            <div style={{overflow:'auto', flex:1}}>
              <table className="table">
                <thead><tr><th>事故编号</th><th>发生时间</th><th>地点</th><th>车辆</th><th>等级</th><th>责任划分</th><th>状态</th><th>登记人</th><th>附件</th><th></th></tr></thead>
                <tbody>
                  {ACCIDENTS.map((a, i) => (
                    <tr key={a.id} className={i === 1 ? "row-active" : ""}>
                      <td className="mono">{a.id}</td>
                      <td className="mono t2">{a.t}</td>
                      <td>{a.site}</td>
                      <td className="mono fw6">{a.v}</td>
                      <td><span className={`pill ${a.level === '未遂' ? 'muted' : a.level === '轻微' ? 'info' : a.level === '一般' ? 'warn' : 'err'}`}><span className="dot"/>{a.level}</span></td>
                      <td>{a.liability}</td>
                      <td><span className={`pill ${a.status === '已结案' ? 'ok' : 'warn'}`}><span className="dot"/>{a.status}</span></td>
                      <td>{a.reporter}</td>
                      <td className="mono">{a.files}</td>
                      <td><button className="btn sm ghost"><Icon name="more" size={13}/></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* 右：详情 */}
          <div className="card acc-detail">
            <div className="card-header">
              <div className="col">
                <span className="t3 mono" style={{fontSize:10}}>ACC-2026-0408-001</span>
                <span className="fw6" style={{fontSize:14, marginTop:2}}>南区分拨 · 出口斜坡 刮蹭事件</span>
              </div>
              <span className="pill warn"><span className="dot"/>理赔中</span>
            </div>

            <div className="acc-meta">
              <div><span className="t3">车辆</span><span className="mono fw6">JD-X07-009</span></div>
              <div><span className="t3">发生时间</span><span className="mono">2026-04-08 09:18:42</span></div>
              <div><span className="t3">事故等级</span><span className="pill warn"><span className="dot"/>一般</span></div>
              <div><span className="t3">责任划分</span><span>我方主责 (70%)</span></div>
              <div><span className="t3">涉事方</span><span>外卖电动车 · 牌号未明</span></div>
              <div><span className="t3">人员伤害</span><span className="tg">无</span></div>
              <div><span className="t3">财产损失</span><span className="mono">¥ 4,200</span></div>
              <div><span className="t3">登记人</span><span>吴桐 · 04-08 09:42</span></div>
            </div>

            <div className="acc-section">
              <div className="ad-block-title">事故描述</div>
              <p className="t2" style={{fontSize:12,lineHeight:1.7,margin:0,padding:'0 16px 12px'}}>
                JD-X07-009 自南区分拨出口斜坡按规划路径出场，行至斜坡中段时一辆外卖电动车自侧方违规切入，
                双方避让不及发生轻微刮蹭。车辆侧裙板划伤约 30cm，无人员受伤。
                现场视频与遥测已完整保留。
              </p>
            </div>

            <div className="acc-section">
              <div className="ad-block-title">现场附件 · 8</div>
              <div className="att-grid">
                {[
                  {icon:"camera", label:"现场监控-1.mp4", size:"32 MB"},
                  {icon:"camera", label:"车端前视-1.mp4", size:"54 MB"},
                  {icon:"lidar",  label:"LiDAR点云.bag", size:"128 MB"},
                  {icon:"doc",    label:"事故认定书.pdf", size:"1.2 MB"},
                  {icon:"camera", label:"现场照片1.jpg", size:"4.8 MB"},
                  {icon:"camera", label:"现场照片2.jpg", size:"3.6 MB"},
                ].map((f, i) => (
                  <div key={i} className="att-card">
                    <div className="att-thumb"><Icon name={f.icon} size={20}/></div>
                    <div className="col" style={{minWidth:0}}>
                      <span className="t1" style={{fontSize:11.5, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{f.label}</span>
                      <span className="t3 mono" style={{fontSize:10}}>{f.size}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="acc-actions">
              <button className="btn">查看完整时间线</button>
              <button className="btn">关联告警 (3)</button>
              <button className="btn primary">提交结案</button>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 客户管理
// ============================================================
const CLIENTS = [
  { name: "京东物流·华东", code: "JD-EC", contact: "张正南", phone: "189****0421", addr: "上海市青浦区华新镇", contract: "2025-03-01 ~ 2027-02-28", days: 672, sites: 14, vehicles: 412, status: "active" },
  { name: "顺丰速运·上海",  code: "SF-SH", contact: "李慕白", phone: "138****8826", addr: "上海市浦东新区临港",  contract: "2024-09-15 ~ 2026-09-14", days: 138, sites: 8,  vehicles: 186, status: "active" },
  { name: "中通南方分拨",    code: "ZT-SN", contact: "周一川", phone: "186****1903", addr: "广州市白云区机场路", contract: "2025-06-01 ~ 2026-05-31", days: 33,  sites: 5,  vehicles: 92,  status: "active" },
  { name: "城北小件中心",    code: "CB-PC", contact: "陈书宁", phone: "139****2204", addr: "北京市顺义区天竺",   contract: "2024-12-20 ~ 2025-12-19", days: 0,   sites: 3,  vehicles: 38,  status: "expiring" },
  { name: "美团即时零售",    code: "MT-IR", contact: "王梓萌", phone: "187****6611", addr: "北京市朝阳区望京",   contract: "2025-08-01 ~ 2027-07-31", days: 824, sites: 12, vehicles: 156, status: "active" },
  { name: "盒马·物流试点",   code: "HM-PL", contact: "赵青远", phone: "133****4408", addr: "杭州市余杭区未来",   contract: "2025-01-10 ~ 2025-12-31", days: 246, sites: 4,  vehicles: 24,  status: "trial" },
];

function ClientPage() {
  return (
    <PageShell active="client" title="客户管理" breadcrumb={["基础信息", "客户管理"]}
      topRight={<><button className="btn"><Icon name="upload" size={13}/>批量导入</button><button className="btn primary"><Icon name="plus" size={13}/>新增客户</button></>}>
      <div className="info-page">
        <div className="info-split">
          {/* 组织树 */}
          <OrgTree active="客户 · 京东物流·华东"/>

          {/* 主体 */}
          <div className="card flex1" style={{display:'flex',flexDirection:'column',minWidth:0}}>
            <Toolbar
              left={<>
                <input className="input" placeholder="搜索客户名称 / 编码 / 联系人" style={{width:280}}/>
                <button className="btn sm">状态：全部 ▾</button>
                <button className="btn sm">合同到期 ▾</button>
              </>}
              right={<>
                <span className="t3 mono" style={{fontSize:11}}>共 32 个客户 · 即将到期 4</span>
                <button className="btn sm">视图：表格 ▾</button>
              </>}/>
            <div style={{flex:1, overflow:'auto'}}>
              <table className="table">
                <thead><tr>
                  <th>客户名称</th><th>编码</th><th>主要联系人</th><th>联系方式</th><th>注册地址</th>
                  <th>合同有效期</th><th>剩余天数</th><th>网点</th><th>车辆</th><th>状态</th><th></th>
                </tr></thead>
                <tbody>
                  {CLIENTS.map((c, i) => (
                    <tr key={c.code}>
                      <td>
                        <div className="row gap-2">
                          <div className="ci-avatar" style={{background: ['#0090e8','#ff7a3d','#1ce8b5','#9d6dff','#ffb547','#4d8cff'][i % 6]}}>
                            {c.name[0]}
                          </div>
                          <div className="col">
                            <span className="fw6">{c.name}</span>
                            <span className="t3 mono" style={{fontSize:10}}>{c.code}</span>
                          </div>
                        </div>
                      </td>
                      <td className="mono t2">{c.code}</td>
                      <td>{c.contact}</td>
                      <td className="mono t2">{c.phone}</td>
                      <td className="t2">{c.addr}</td>
                      <td className="mono t2" style={{fontSize:11}}>{c.contract}</td>
                      <td>
                        {c.days <= 0 ? <span className="pill err"><span className="dot"/>已过期</span>
                          : c.days <= 60 ? <span className="pill warn"><span className="dot"/>{c.days}天</span>
                          : <span className="mono t2">{c.days}天</span>}
                      </td>
                      <td className="mono">{c.sites}</td>
                      <td className="mono fw6">{c.vehicles}</td>
                      <td><span className={`pill ${c.status === 'active' ? 'ok' : c.status === 'expiring' ? 'err' : 'info'}`}><span className="dot"/>{c.status === 'active' ? '运营中' : c.status === 'expiring' ? '到期续签' : '试点'}</span></td>
                      <td>
                        <div className="row gap-1">
                          <button className="btn sm ghost"><Icon name="edit" size={12}/></button>
                          <button className="btn sm ghost"><Icon name="more" size={12}/></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ---------- 组织树 (左侧) ----------
function OrgTree({ active }) {
  const tree = [
    { type: "client", label: "京东物流·华东", count: "412 台", expand: true, kids: [
      { label: "亚一中心仓", count: "182 台" },
      { label: "南区分拨", count: "104 台" },
      { label: "东塔配送站", count: "62 台" },
      { label: "北门枢纽", count: "44 台" },
      { label: "西区充电场", count: "20 台" },
    ]},
    { type: "client", label: "顺丰速运·上海", count: "186 台" },
    { type: "client", label: "中通南方分拨", count: "92 台" },
    { type: "client", label: "城北小件中心", count: "38 台", warn: true },
    { type: "client", label: "美团即时零售", count: "156 台" },
    { type: "client", label: "盒马·物流试点", count: "24 台" },
  ];
  return (
    <div className="card org-tree">
      <div className="card-header">
        <span className="card-title">组织 · 客户</span>
        <button className="btn sm icon ghost"><Icon name="plus" size={11}/></button>
      </div>
      <div style={{padding:'8px 6px'}}>
        <div className="tree-search">
          <Icon name="search" size={12}/>
          <input placeholder="搜索..."/>
        </div>
        <div className="tree-row root">
          <Icon name="tree" size={13}/><span className="flex1 fw6">全部客户</span><span className="mono t3">32</span>
        </div>
        {tree.map((n, i) => (
          <div key={i}>
            <div className={"tree-row " + (active === `客户 · ${n.label}` ? "active" : "")}>
              <Icon name={n.expand ? "chevd" : "chevr"} size={11}/>
              <Icon name="client" size={13} className={n.warn ? "tr" : ""}/>
              <span className="flex1">{n.label}</span>
              <span className="mono t3" style={{fontSize:10}}>{n.count}</span>
            </div>
            {n.expand && n.kids && n.kids.map((k, j) => (
              <div key={j} className="tree-row sub">
                <Icon name="site" size={12}/>
                <span className="flex1">{k.label}</span>
                <span className="mono t3" style={{fontSize:10}}>{k.count}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}

// ============================================================
// PAGE: 网点管理
// ============================================================
const SITES = [
  { name: "亚一中心仓",  code: "JD-YA1",  client: "京东物流·华东", coord: "31.1942, 121.6174", manager: "沈知行", phone: "189****0421", hours: "00:00 ~ 24:00", vehicles: 182, status: "运营中" },
  { name: "南区分拨",    code: "JD-NQ1",  client: "京东物流·华东", coord: "31.1612, 121.6442", manager: "吴桐",   phone: "139****2204", hours: "06:00 ~ 22:00", vehicles: 104, status: "运营中" },
  { name: "东塔配送站",   code: "JD-DT2",  client: "京东物流·华东", coord: "31.2101, 121.6588", manager: "周野",   phone: "186****1903", hours: "07:00 ~ 21:00", vehicles: 62,  status: "运营中" },
  { name: "北门枢纽",    code: "JD-BM1",  client: "京东物流·华东", coord: "31.2244, 121.6011", manager: "林夕",   phone: "133****4408", hours: "00:00 ~ 24:00", vehicles: 44,  status: "运营中" },
  { name: "西区充电场",  code: "JD-XQC1", client: "京东物流·华东", coord: "31.1998, 121.5811", manager: "赵青远", phone: "187****6611", hours: "00:00 ~ 24:00", vehicles: 20,  status: "运营中" },
  { name: "运河支线",    code: "JD-YH3",  client: "中通南方分拨",  coord: "31.1718, 121.6912", manager: "王梓萌", phone: "138****8826", hours: "08:00 ~ 18:00", vehicles: 4,   status: "维护中" },
];

function SitePage() {
  return (
    <PageShell active="site" title="网点管理" breadcrumb={["基础信息", "网点管理"]}
      topRight={<><button className="btn"><Icon name="globe" size={13}/>地图视图</button><button className="btn primary"><Icon name="plus" size={13}/>新增网点</button></>}>
      <div className="info-page">
        <div className="info-split">
          <OrgTree active="客户 · 京东物流·华东"/>
          <div className="card flex1" style={{display:'flex',flexDirection:'column',minWidth:0}}>
            <Toolbar
              left={<>
                <input className="input" placeholder="搜索网点 / 编码 / 负责人" style={{width:260}}/>
                <button className="btn sm">客户：京东物流·华东 ×</button>
                <button className="btn sm">状态 ▾</button>
              </>}
              right={<span className="t3 mono" style={{fontSize:11}}>共 96 个网点 · 静默 9</span>}/>
            <div style={{flex:1, overflow:'auto'}}>
              <table className="table">
                <thead><tr><th>网点名称</th><th>编码</th><th>所属客户</th><th>坐标</th><th>负责人</th><th>联系方式</th><th>运营时段</th><th>车辆数</th><th>状态</th><th></th></tr></thead>
                <tbody>
                  {SITES.map(s => (
                    <tr key={s.code}>
                      <td><div className="row gap-2"><Icon name="site" size={14} className="tx"/><span className="fw6">{s.name}</span></div></td>
                      <td className="mono t2">{s.code}</td>
                      <td>{s.client}</td>
                      <td className="mono t2" style={{fontSize:11}}>{s.coord}</td>
                      <td>{s.manager}</td>
                      <td className="mono t2">{s.phone}</td>
                      <td className="mono t2">{s.hours}</td>
                      <td className="mono fw6">{s.vehicles}</td>
                      <td><span className={`pill ${s.status === '运营中' ? 'ok' : 'warn'}`}><span className="dot"/>{s.status}</span></td>
                      <td><button className="btn sm ghost"><Icon name="more" size={13}/></button></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 车辆档案 (数字孪生)
// ============================================================
const VEHICLES = [
  { id: "JD-X07-009", brand: "新石器", model: "X-07 Pro", plate: "沪AD·X0009", client: "城北小件中心", site: "南区分拨", responsible: "吴桐", batch: "2025-Q3", mileage: 18420, status: "alert" },
  { id: "JD-X07-077", brand: "白犀牛", model: "B-Logistics 200", plate: "沪AD·X0077", client: "京东物流·华东", site: "西区充电场", responsible: "林夕", batch: "2025-Q3", mileage: 22180, status: "charging" },
  { id: "JD-X07-118", brand: "新石器", model: "X-07 Pro", plate: "沪AD·X0118", client: "京东物流·华东", site: "亚一中心仓", responsible: "沈知行", batch: "2025-Q4", mileage: 9620, status: "moving" },
  { id: "JD-X07-156", brand: "九识智能", model: "Z5 标准", plate: "沪AD·X0156", client: "顺丰速运", site: "亚一中心仓", responsible: "沈知行", batch: "2026-Q1", mileage: 4220, status: "moving" },
  { id: "JD-X07-204", brand: "新石器", model: "X-07 Pro", plate: "沪AD·X0204", client: "京东物流·华东", site: "北门枢纽", responsible: "林夕", batch: "2025-Q4", mileage: 11840, status: "moving" },
  { id: "JD-X07-225", brand: "新石器", model: "X-07 Pro", plate: "沪AD·X0225", client: "京东物流·华东", site: "亚一中心仓", responsible: "沈知行", batch: "2026-Q1", mileage: 3120, status: "moving" },
  { id: "JD-X07-312", brand: "九识智能", model: "Z5 重载", plate: "沪AD·X0312", client: "中通南方分拨", site: "亚一中心仓", responsible: "周野", batch: "2026-Q1", mileage: 2840, status: "moving" },
];

function VehiclePage() {
  return (
    <PageShell active="vehicle" title="车辆档案" breadcrumb={["基础信息", "车辆档案"]}
      topRight={<>
        <div className="seg"><button className="seg-item">表格</button><button className="seg-item active">数字孪生</button></div>
        <button className="btn"><Icon name="upload" size={13}/>批量导入</button>
        <button className="btn primary"><Icon name="plus" size={13}/>录入车辆</button>
      </>}>
      <div className="vehicle-page">
        <div className="card vehicle-list">
          <Toolbar
            left={<>
              <input className="input" placeholder="车牌 / 车辆号" style={{width:200}}/>
              <button className="btn sm">品牌 ▾</button>
              <button className="btn sm">客户 ▾</button>
              <button className="btn sm">状态 ▾</button>
            </>}
            right={<span className="t3 mono" style={{fontSize:11}}>共 1,284 台</span>}/>
          <div style={{flex:1, overflow:'auto'}}>
            <table className="table compact">
              <thead><tr><th>车辆号</th><th>品牌 / 型号</th><th>车牌</th><th>所属客户</th><th>责任人</th><th>里程</th><th>状态</th></tr></thead>
              <tbody>
                {VEHICLES.map((v, i) => (
                  <tr key={v.id} className={i === 0 ? "row-active" : ""}>
                    <td className="mono fw6">{v.id}</td>
                    <td><span className="t1">{v.brand}</span><span className="t3" style={{marginLeft:6,fontSize:11}}>{v.model}</span></td>
                    <td className="mono t2">{v.plate}</td>
                    <td className="t2" style={{fontSize:11.5}}>{v.client}</td>
                    <td>{v.responsible}</td>
                    <td className="mono">{v.mileage.toLocaleString()}<span className="t3" style={{fontSize:10,marginLeft:2}}>km</span></td>
                    <td>
                      <span className={`pill ${v.status === 'alert' ? 'err' : v.status === 'charging' ? 'info' : v.status === 'moving' ? 'ok' : 'muted'}`}>
                        <span className="dot"/>{v.status === 'alert' ? '告警' : v.status === 'charging' ? '充电' : v.status === 'moving' ? '运输中' : '空闲'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <DigitalTwinCard/>
      </div>
    </PageShell>
  );
}

// 数字孪生卡片
function DigitalTwinCard() {
  return (
    <div className="card twin-card">
      <div className="card-header">
        <div className="col">
          <span className="t3 mono" style={{fontSize:10}}>数字孪生 · LIVE</span>
          <span className="fw6" style={{fontSize:14, marginTop:2}}>JD-X07-009 <span className="t3" style={{fontSize:11,marginLeft:6}}>新石器 X-07 Pro · 沪AD·X0009</span></span>
        </div>
        <span className="pill err"><span className="dot"/>告警 · 电量过低</span>
      </div>

      {/* 3D 示意 */}
      <div className="twin-viewport">
        <svg viewBox="0 0 360 200" style={{width:'100%',height:'100%'}}>
          <defs>
            <linearGradient id="vBody" x1="0" x2="0" y1="0" y2="1">
              <stop offset="0%" stopColor="#0090e8"/>
              <stop offset="100%" stopColor="#005a91"/>
            </linearGradient>
            <radialGradient id="vGround" cx="50%" cy="50%">
              <stop offset="0%" stopColor="rgba(0,229,255,0.18)"/>
              <stop offset="100%" stopColor="rgba(0,229,255,0)"/>
            </radialGradient>
            <pattern id="floor" width="20" height="20" patternUnits="userSpaceOnUse" patternTransform="skewX(-30)">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(0,229,255,0.08)" strokeWidth="0.5"/>
            </pattern>
          </defs>
          {/* 地面 */}
          <rect width="360" height="200" fill="url(#vGround)"/>
          <ellipse cx="180" cy="170" rx="110" ry="12" fill="rgba(0,229,255,0.08)"/>
          {/* 等距示意车 */}
          <g transform="translate(180 110)">
            {/* 阴影 */}
            <ellipse cx="0" cy="55" rx="80" ry="8" fill="rgba(0,0,0,0.4)"/>
            {/* 车身（等距投影 box） */}
            {/* top */}
            <polygon points="-60,-20 60,-20 90,-5 -30,-5" fill="#1a2940" stroke="rgba(0,229,255,0.35)" strokeWidth="1"/>
            {/* front */}
            <polygon points="60,-20 60,30 90,45 90,-5" fill="url(#vBody)" stroke="rgba(0,229,255,0.5)" strokeWidth="1"/>
            {/* side */}
            <polygon points="-60,-20 -60,30 60,30 60,-20" fill="#0c1828" stroke="rgba(0,229,255,0.35)" strokeWidth="1"/>
            {/* 驾驶舱 */}
            <polygon points="40,-20 60,-20 75,-12 60,-12" fill="rgba(0,229,255,0.35)"/>
            {/* 货厢分割 */}
            <line x1="0" y1="-20" x2="0" y2="30" stroke="rgba(0,229,255,0.25)" strokeWidth="0.6"/>
            {/* 车轮 */}
            <ellipse cx="-40" cy="32" rx="8" ry="3" fill="#020407" stroke="rgba(0,229,255,0.4)" strokeWidth="0.6"/>
            <ellipse cx="40" cy="32" rx="8" ry="3" fill="#020407" stroke="rgba(0,229,255,0.4)" strokeWidth="0.6"/>
            <ellipse cx="68" cy="40" rx="8" ry="3" fill="#020407" stroke="rgba(0,229,255,0.4)" strokeWidth="0.6"/>
            {/* 传感器 */}
            <circle cx="60" cy="-22" r="3" fill="var(--data-cyan)"><animate attributeName="opacity" values="0.4;1;0.4" dur="1.6s" repeatCount="indefinite"/></circle>
            <circle cx="-60" cy="-22" r="2.5" fill="var(--data-cyan)"/>
            <circle cx="0" cy="-23" r="2" fill="var(--err)"><animate attributeName="opacity" values="0.3;1;0.3" dur="1s" repeatCount="indefinite"/></circle>
            {/* 标注线 */}
            <g stroke="rgba(0,229,255,0.4)" strokeWidth="0.4" fill="none">
              <path d="M -60 -20 L -90 -45" /><circle cx="-90" cy="-45" r="2" fill="var(--data-cyan)"/>
              <path d="M 60 -22 L 105 -50" /><circle cx="105" cy="-50" r="2" fill="var(--data-cyan)"/>
              <path d="M 0 -23 L 0 -55" /><circle cx="0" cy="-55" r="2" fill="var(--err)"/>
              <path d="M 90 20 L 130 30" /><circle cx="130" cy="30" r="2" fill="var(--data-cyan)"/>
            </g>
          </g>
          {/* 标签 */}
          <g fontFamily="var(--font-mono)" fontSize="9" fill="var(--text-2)">
            <text x="-2" y="48" textAnchor="end">环视相机 ×4</text>
            <text x="115" y="48" textAnchor="start">前向 LiDAR</text>
            <text x="180" y="50" textAnchor="middle" fill="var(--err)">毫米波雷达</text>
            <text x="316" y="146" textAnchor="start">货厢 · 6格</text>
          </g>
        </svg>
        <div className="twin-overlay">
          <span className="mono t3" style={{fontSize:10}}>VIEW</span>
          <button className="btn sm">等距</button>
          <button className="btn sm">侧视</button>
          <button className="btn sm">俯视</button>
        </div>
      </div>

      {/* 实时遥测 */}
      <div className="telemetry">
        <div className="tel-cell">
          <div className="row gap-1 t3"><Icon name="battery" size={11}/><span style={{fontSize:11}}>电池</span></div>
          <div className="kpi-value tr" style={{fontSize:20}}>18%</div>
          <div className="t3 mono" style={{fontSize:10}}>剩余 12 km</div>
        </div>
        <div className="tel-cell">
          <div className="row gap-1 t3"><Icon name="speed" size={11}/><span style={{fontSize:11}}>速度</span></div>
          <div className="kpi-value" style={{fontSize:20}}>12<span style={{fontSize:11,marginLeft:2}}>km/h</span></div>
          <div className="t3 mono" style={{fontSize:10}}>限速 25</div>
        </div>
        <div className="tel-cell">
          <div className="row gap-1 t3"><Icon name="signal" size={11}/><span style={{fontSize:11}}>信号</span></div>
          <div className="kpi-value tg" style={{fontSize:20}}>5G</div>
          <div className="t3 mono" style={{fontSize:10}}>RSRP -78</div>
        </div>
        <div className="tel-cell">
          <div className="row gap-1 t3"><Icon name="package" size={11}/><span style={{fontSize:11}}>载重</span></div>
          <div className="kpi-value tw" style={{fontSize:20}}>54%</div>
          <div className="t3 mono" style={{fontSize:10}}>3 / 6 格</div>
        </div>
        <div className="tel-cell">
          <div className="row gap-1 t3"><Icon name="temp" size={11}/><span style={{fontSize:11}}>电池温度</span></div>
          <div className="kpi-value" style={{fontSize:20}}>32<span style={{fontSize:11}}>°C</span></div>
          <div className="t3 mono" style={{fontSize:10}}>正常</div>
        </div>
        <div className="tel-cell">
          <div className="row gap-1 t3"><Icon name="wifi" size={11}/><span style={{fontSize:11}}>遥测延迟</span></div>
          <div className="kpi-value tg" style={{fontSize:20}}>146<span style={{fontSize:11}}>ms</span></div>
          <div className="t3 mono" style={{fontSize:10}}>稳定</div>
        </div>
      </div>

      <div className="twin-tabs">
        <button className="td-tab active">基础档案</button>
        <button className="td-tab">维保记录 · 14</button>
        <button className="td-tab">告警历史 · 23</button>
        <button className="td-tab">事故记录 · 1</button>
        <button className="td-tab">OTA · v2.4.1</button>
      </div>

      <div className="archive">
        <div className="ar-cell"><span className="t3">车辆号</span><span className="mono">JD-X07-009</span></div>
        <div className="ar-cell"><span className="t3">品牌型号</span><span>新石器 X-07 Pro</span></div>
        <div className="ar-cell"><span className="t3">车牌</span><span className="mono">沪AD·X0009</span></div>
        <div className="ar-cell"><span className="t3">VIN</span><span className="mono" style={{fontSize:11}}>LWBNS24X9PSE0009</span></div>
        <div className="ar-cell"><span className="t3">投放批次</span><span>2025-Q3</span></div>
        <div className="ar-cell"><span className="t3">投放日期</span><span className="mono">2025-08-14</span></div>
        <div className="ar-cell"><span className="t3">所属客户</span><span>城北小件中心</span></div>
        <div className="ar-cell"><span className="t3">归属网点</span><span>南区分拨</span></div>
        <div className="ar-cell"><span className="t3">责任人</span><span>吴桐</span></div>
        <div className="ar-cell"><span className="t3">累计里程</span><span className="mono">18,420 km</span></div>
      </div>
    </div>
  );
}

// ============================================================
// PAGE: 路线管理
// ============================================================
const ROUTES = [
  { id: "R-04", name: "亚一仓 → 南区分拨", from: "亚一中心仓", to: "南区分拨", stops: 6, length: 8.4, brands: 3, vehicles: 22, daily: 184, status: "运行中" },
  { id: "R-02", name: "北门枢纽 → 东塔配送站", from: "北门枢纽", to: "东塔配送站", stops: 4, length: 4.2, brands: 2, vehicles: 14, daily: 138, status: "运行中" },
  { id: "R-08", name: "亚一仓 → 城北小件中心", from: "亚一中心仓", to: "城北小件中心", stops: 8, length: 12.6, brands: 3, vehicles: 18, daily: 92, status: "运行中" },
  { id: "R-11", name: "亚一仓 → 运河支线", from: "亚一中心仓", to: "运河支线", stops: 5, length: 6.8, brands: 2, vehicles: 9, daily: 64, status: "运行中" },
  { id: "R-15", name: "南区分拨 → 运河支线", from: "南区分拨", to: "运河支线", stops: 7, length: 9.4, brands: 3, vehicles: 6, daily: 42, status: "试运行" },
];

const ROUTE_STOPS = [
  { name: "亚一中心仓",  type: "仓库",  km: 0,    eta: "00:00", action: "装载" },
  { name: "G2 出场闸口", type: "节点",  km: 0.2,  eta: "00:01", action: "校验" },
  { name: "园区主路口",  type: "节点",  km: 1.8,  eta: "00:08", action: "—" },
  { name: "二号桥",      type: "节点",  km: 3.4,  eta: "00:14", action: "—" },
  { name: "斜坡控速点",  type: "限速",  km: 5.6,  eta: "00:22", action: "降至 8 km/h" },
  { name: "南区入闸",    type: "节点",  km: 7.8,  eta: "00:30", action: "校验" },
  { name: "南区分拨",    type: "仓库",  km: 8.4,  eta: "00:34", action: "卸载" },
];

function RoutePage() {
  return (
    <PageShell active="route" title="路线管理" breadcrumb={["基础信息", "路线管理"]}
      topRight={<><button className="btn"><Icon name="upload" size={13}/>对接行驶线</button><button className="btn primary"><Icon name="plus" size={13}/>规划新路线</button></>}>
      <div className="route-page">
        <div className="card route-list">
          <div className="card-header">
            <span className="card-title">路线列表 · 23</span>
            <input className="input" placeholder="搜索..." style={{width:160}}/>
          </div>
          <div style={{overflow:'auto', flex:1}}>
            {ROUTES.map((r, i) => (
              <div key={r.id} className={"rt-row " + (i === 0 ? "active" : "")}>
                <div className="row between">
                  <span className="mono fw6 tx">{r.id}</span>
                  <span className={`pill ${r.status === '运行中' ? 'ok' : 'warn'}`}><span className="dot"/>{r.status}</span>
                </div>
                <div className="fw5" style={{fontSize:13, marginTop:4}}>{r.name}</div>
                <div className="row gap-3 t3" style={{fontSize:11, marginTop:6}}>
                  <span className="row gap-1"><Icon name="route" size={10}/>{r.length}km · {r.stops}站</span>
                  <span className="row gap-1"><Icon name="vehicle" size={10}/>{r.vehicles}台</span>
                  <span className="row gap-1"><Icon name="package" size={10}/>{r.daily}单/日</span>
                </div>
                <div className="t3" style={{fontSize:11,marginTop:4}}>适配 <span className="t1 fw6">{r.brands}</span> 个品牌</div>
              </div>
            ))}
          </div>
        </div>

        {/* 路线详情 + 地图 */}
        <div className="route-main">
          <div className="card">
            <div className="card-header">
              <div className="col">
                <span className="t3 mono" style={{fontSize:10}}>R-04 · 全品牌通用</span>
                <span className="fw6" style={{fontSize:14, marginTop:2}}>亚一仓 → 南区分拨</span>
              </div>
              <div className="row gap-2">
                <div className="seg">
                  <button className="seg-item active">规划路径</button>
                  <button className="seg-item">实测轨迹</button>
                  <button className="seg-item">热力</button>
                </div>
                <button className="btn"><Icon name="edit" size={13}/>编辑路径</button>
              </div>
            </div>
            <div className="route-map">
              <svg viewBox="0 0 800 320" preserveAspectRatio="none" style={{width:'100%',height:'100%'}}>
                <defs>
                  <pattern id="rmgrid" width="20" height="20" patternUnits="userSpaceOnUse">
                    <path d="M 20 0 L 0 0 0 20" fill="none" stroke="rgba(0,229,255,0.05)" strokeWidth="0.4"/>
                  </pattern>
                </defs>
                <rect width="800" height="320" fill="url(#rmgrid)"/>
                {/* 园区背景示意 */}
                <g opacity="0.4">
                  <rect x="40" y="60" width="120" height="80" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.1)"/>
                  <rect x="240" y="40" width="100" height="60" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.1)"/>
                  <rect x="440" y="70" width="80" height="50" fill="rgba(255,255,255,0.03)" stroke="rgba(255,255,255,0.1)"/>
                  <rect x="600" y="180" width="140" height="80" fill="rgba(0,144,232,0.08)" stroke="rgba(0,144,232,0.3)"/>
                  <rect x="40" y="200" width="100" height="60" fill="rgba(28,232,181,0.08)" stroke="rgba(28,232,181,0.3)"/>
                </g>
                {/* 主干道 */}
                <g stroke="rgba(255,255,255,0.12)" strokeWidth="14" fill="none" opacity="0.6">
                  <path d="M 0 160 L 800 160"/>
                  <path d="M 200 0 L 200 320"/>
                  <path d="M 500 0 L 500 320"/>
                </g>
                <g stroke="rgba(255,255,255,0.05)" strokeWidth="13" strokeDasharray="4 6" fill="none">
                  <path d="M 0 160 L 800 160"/>
                </g>
                {/* 路线 */}
                <path d="M 90 240 L 200 240 L 200 160 L 500 160 L 500 220 L 670 220" fill="none" stroke="var(--data-cyan)" strokeWidth="3" strokeDasharray="0" strokeLinecap="round"/>
                <path d="M 90 240 L 200 240 L 200 160 L 500 160 L 500 220 L 670 220" fill="none" stroke="var(--brand-400)" strokeWidth="3" strokeDasharray="6 4" strokeLinecap="round" style={{animation:'flow-dash 2s linear infinite'}}/>
                {/* 车辆（沿线） */}
                <circle cx="350" cy="160" r="6" fill="var(--data-cyan)" stroke="#001428" strokeWidth="1.5">
                  <animate attributeName="cx" values="200;500" dur="6s" repeatCount="indefinite"/>
                </circle>
                {/* 站点 */}
                {[
                  {x:90, y:240, label:"亚一仓", type:"warehouse"},
                  {x:200, y:240, label:"G2闸口", type:"node"},
                  {x:200, y:160, label:"主路口", type:"node"},
                  {x:340, y:160, label:"二号桥", type:"node"},
                  {x:500, y:160, label:"斜坡限速", type:"speed"},
                  {x:500, y:220, label:"南区入闸", type:"node"},
                  {x:670, y:220, label:"南区分拨", type:"warehouse"},
                ].map((s, i) => (
                  <g key={i} transform={`translate(${s.x} ${s.y})`}>
                    {s.type === "warehouse" ? (
                      <>
                        <rect x="-9" y="-9" width="18" height="18" fill="var(--brand-500)" stroke="var(--data-cyan)" strokeWidth="1.5" rx="2"/>
                        <text y="3" textAnchor="middle" fontSize="9" fill="white" fontWeight="700">仓</text>
                      </>
                    ) : s.type === "speed" ? (
                      <>
                        <circle r="7" fill="var(--warn)" stroke="#001428" strokeWidth="1.5"/>
                        <text y="3" textAnchor="middle" fontSize="9" fill="#001428" fontWeight="700">!</text>
                      </>
                    ) : (
                      <circle r="5" fill="var(--bg-2)" stroke="var(--data-cyan)" strokeWidth="1.5"/>
                    )}
                    <text y={s.type === "warehouse" ? -16 : -12} textAnchor="middle" fontSize="10" fill="var(--text-2)" fontFamily="var(--font-sans)">{s.label}</text>
                    <text y={s.type === "warehouse" ? -28 : -22} textAnchor="middle" fontSize="9" fill="var(--text-3)" fontFamily="var(--font-mono)">{i+1}</text>
                  </g>
                ))}
              </svg>
              <div className="map-corner tl">
                <span className="pill ok"><span className="dot"/>当前 22 台车在线</span>
              </div>
              <div className="map-corner tr">
                <span className="t3 mono" style={{fontSize:10}}>BRANDS</span>
                <span className="pill muted">新石器</span>
                <span className="pill muted">白犀牛</span>
                <span className="pill muted">九识</span>
              </div>
            </div>
          </div>

          {/* 站点时刻表 */}
          <div className="card">
            <div className="card-header">
              <span className="card-title">站点时刻表 · 7 站</span>
              <span className="t3 mono" style={{fontSize:11}}>总长 8.4 km · 标称耗时 34 min</span>
            </div>
            <table className="table">
              <thead><tr><th style={{width:32}}>#</th><th>站点</th><th>类型</th><th>累计里程</th><th>到达时刻 (T+)</th><th>动作</th><th>采集</th><th></th></tr></thead>
              <tbody>
                {ROUTE_STOPS.map((s, i) => (
                  <tr key={i}>
                    <td><div className="step-circle">{i+1}</div></td>
                    <td className="fw6">{s.name}</td>
                    <td><span className={`pill ${s.type === '仓库' ? 'info' : s.type === '限速' ? 'warn' : 'muted'}`}><span className="dot"/>{s.type}</span></td>
                    <td className="mono">{s.km} km</td>
                    <td className="mono t2">{s.eta}</td>
                    <td>{s.action}</td>
                    <td><div className="row gap-1"><span className="dot-tag tg">坐标</span><span className="dot-tag tg">影像</span></div></td>
                    <td><button className="btn sm ghost"><Icon name="more" size={12}/></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 用户管理
// ============================================================
const USERS = [
  { name: "沈知行", login: "shenzhixing", phone: "189****0421", role: "调度组长", org: "京东物流·华东 / 调度部", last: "2026-04-28 09:48", state: "active" },
  { name: "吴桐",   login: "wutong",      phone: "139****2204", role: "高级处置员", org: "京东物流·华东 / 处置部", last: "2026-04-28 10:12", state: "active" },
  { name: "周野",   login: "zhouye",      phone: "186****1903", role: "处置员",     org: "京东物流·华东 / 处置部", last: "2026-04-28 10:01", state: "active" },
  { name: "林夕",   login: "linxi",       phone: "133****4408", role: "调度员",     org: "京东物流·华东 / 调度部", last: "2026-04-28 09:54", state: "active" },
  { name: "赵青远", login: "zhaoqingyuan", phone: "187****6611", role: "运营经理",   org: "总部 / 运营管理部",     last: "2026-04-27 18:32", state: "active" },
  { name: "王梓萌", login: "wangzimeng",  phone: "138****8826", role: "客户管理员", org: "顺丰速运·上海",           last: "2026-04-26 11:08", state: "disabled" },
  { name: "陈书宁", login: "chenshuning", phone: "139****2204", role: "只读分析师", org: "总部 / 数据分析部",      last: "2026-04-25 16:20", state: "active" },
];

function UserPage() {
  return (
    <PageShell active="user" title="用户管理" breadcrumb={["系统配置", "用户管理"]}
      topRight={<>
        <button className="btn"><Icon name="upload" size={13}/>批量导入</button>
        <button className="btn primary"><Icon name="plus" size={13}/>新建用户</button>
      </>}>
      <div className="info-page">
        <div className="info-split">
          <OrgTreeMech/>
          <div className="card flex1" style={{display:'flex',flexDirection:'column',minWidth:0}}>
            <Toolbar
              left={<>
                <input className="input" placeholder="姓名 / 登录名 / 手机号" style={{width:240}}/>
                <button className="btn sm">角色 ▾</button>
                <button className="btn sm">机构 ▾</button>
                <button className="btn sm">状态 ▾</button>
              </>}
              right={<span className="t3 mono" style={{fontSize:11}}>共 142 用户 · 启用 138</span>}/>
            <div style={{flex:1, overflow:'auto'}}>
              <table className="table">
                <thead><tr>
                  <th style={{width:32}}><input type="checkbox"/></th>
                  <th>姓名</th><th>登录名</th><th>手机号</th><th>角色</th><th>所属机构</th><th>最近登录</th><th>状态</th><th>操作</th>
                </tr></thead>
                <tbody>
                  {USERS.map((u, i) => (
                    <tr key={u.login}>
                      <td><input type="checkbox"/></td>
                      <td><div className="row gap-2"><div className="ci-avatar sm" style={{background: ['#0090e8','#ff7a3d','#1ce8b5','#9d6dff','#ffb547','#4d8cff','#ff66c4'][i % 7]}}>{u.name[0]}</div><span className="fw6">{u.name}</span></div></td>
                      <td className="mono t2">{u.login}</td>
                      <td className="mono t2">{u.phone}</td>
                      <td><span className="pill info"><span className="dot"/>{u.role}</span></td>
                      <td className="t2">{u.org}</td>
                      <td className="mono t2" style={{fontSize:11}}>{u.last}</td>
                      <td><span className={`pill ${u.state === 'active' ? 'ok' : 'muted'}`}><span className="dot"/>{u.state === 'active' ? '启用' : '禁用'}</span></td>
                      <td>
                        <div className="row gap-1">
                          <button className="btn sm ghost" title="编辑"><Icon name="edit" size={12}/></button>
                          <button className="btn sm ghost" title="重置密码"><Icon name="key" size={12}/></button>
                          <button className="btn sm ghost" title="禁用"><Icon name="ban" size={12}/></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// 机构树（用户/角色复用）
function OrgTreeMech() {
  return (
    <div className="card org-tree">
      <div className="card-header">
        <span className="card-title">组织 · 机构</span>
        <button className="btn sm icon ghost"><Icon name="plus" size={11}/></button>
      </div>
      <div style={{padding:'8px 6px'}}>
        <div className="tree-row root"><Icon name="tree" size={13}/><span className="flex1 fw6">无人物流车运营服务</span><span className="mono t3">142</span></div>
        <div className="tree-row active"><Icon name="chevd" size={11}/><Icon name="users" size={13}/><span className="flex1">总部</span><span className="mono t3" style={{fontSize:10}}>34</span></div>
          <div className="tree-row sub"><Icon name="users" size={12}/><span className="flex1">运营管理部</span><span className="mono t3" style={{fontSize:10}}>12</span></div>
          <div className="tree-row sub"><Icon name="users" size={12}/><span className="flex1">数据分析部</span><span className="mono t3" style={{fontSize:10}}>8</span></div>
          <div className="tree-row sub"><Icon name="users" size={12}/><span className="flex1">技术支持部</span><span className="mono t3" style={{fontSize:10}}>14</span></div>
        <div className="tree-row"><Icon name="chevd" size={11}/><Icon name="users" size={13}/><span className="flex1">京东物流·华东</span><span className="mono t3" style={{fontSize:10}}>62</span></div>
          <div className="tree-row sub"><Icon name="users" size={12}/><span className="flex1">调度部</span><span className="mono t3" style={{fontSize:10}}>28</span></div>
          <div className="tree-row sub"><Icon name="users" size={12}/><span className="flex1">处置部</span><span className="mono t3" style={{fontSize:10}}>22</span></div>
          <div className="tree-row sub"><Icon name="users" size={12}/><span className="flex1">运维班组</span><span className="mono t3" style={{fontSize:10}}>12</span></div>
        <div className="tree-row"><Icon name="chevr" size={11}/><Icon name="users" size={13}/><span className="flex1">顺丰速运·上海</span><span className="mono t3" style={{fontSize:10}}>18</span></div>
        <div className="tree-row"><Icon name="chevr" size={11}/><Icon name="users" size={13}/><span className="flex1">中通南方分拨</span><span className="mono t3" style={{fontSize:10}}>14</span></div>
        <div className="tree-row"><Icon name="chevr" size={11}/><Icon name="users" size={13}/><span className="flex1">城北小件中心</span><span className="mono t3" style={{fontSize:10}}>8</span></div>
        <div className="tree-row"><Icon name="chevr" size={11}/><Icon name="users" size={13}/><span className="flex1">其它客户 (4)</span><span className="mono t3" style={{fontSize:10}}>6</span></div>
      </div>
    </div>
  );
}

// ============================================================
// PAGE: 角色权限矩阵
// ============================================================
const ROLE_LIST = [
  { id: "admin",   name: "超级管理员", users: 2, scope: "平台全局",     editable: false },
  { id: "ops_mgr", name: "运营经理",   users: 8, scope: "总部",         editable: true },
  { id: "dispatch_lead", name: "调度组长", users: 14, scope: "网点级",   editable: true, current: true },
  { id: "dispatch", name: "调度员",   users: 38, scope: "网点级",       editable: true },
  { id: "ops",     name: "处置员",     users: 32, scope: "客户级",       editable: true },
  { id: "client_admin", name: "客户管理员", users: 18, scope: "本客户",   editable: true },
  { id: "auditor", name: "审计员",     users: 4,  scope: "全局只读",     editable: true },
  { id: "analyst", name: "只读分析师", users: 26, scope: "脱敏数据",     editable: true },
];

const PERMS = [
  { module: "运行监测",  perms: [["查看", true], ["筛选", true], ["导出", true], ["远程接管", false]] },
  { module: "任务记录",  perms: [["查看", true], ["创建", true], ["编辑", true], ["撤销", true], ["导出", true]] },
  { module: "告警处置",  perms: [["查看", true], ["认领", true], ["处置", true], ["忽略", true], ["复核", false]] },
  { module: "事故管理",  perms: [["查看", true], ["登记", true], ["编辑", true], ["关闭", false], ["附件上传", true]] },
  { module: "客户管理",  perms: [["查看", true], ["新增", false], ["编辑", false], ["删除", false]] },
  { module: "网点管理",  perms: [["查看", true], ["新增", true], ["编辑", true], ["删除", false]] },
  { module: "车辆档案",  perms: [["查看", true], ["新增", false], ["编辑", true], ["状态更新", true], ["批量操作", false]] },
  { module: "路线管理",  perms: [["查看", true], ["规划", true], ["编辑", true], ["删除", false]] },
  { module: "用户管理",  perms: [["查看", false], ["新增", false], ["编辑", false], ["禁用", false]] },
  { module: "系统设置",  perms: [["查看", false], ["修改", false]] },
];

function RolePage() {
  return (
    <PageShell active="role" title="角色权限" breadcrumb={["系统配置", "角色权限"]}
      topRight={<><button className="btn"><Icon name="doc" size={13}/>权限矩阵导出</button><button className="btn primary"><Icon name="plus" size={13}/>新增角色</button></>}>
      <div className="role-page">
        {/* 左：角色列表 */}
        <div className="card role-list">
          <div className="card-header">
            <span className="card-title">角色 · 8</span>
            <input className="input" placeholder="搜索..." style={{width:140}}/>
          </div>
          <div style={{padding:'4px 6px'}}>
            {ROLE_LIST.map(r => (
              <div key={r.id} className={"role-row " + (r.current ? "active" : "")}>
                <Icon name="shield" size={14} className={r.current ? "tx" : "t3"}/>
                <div className="col flex1" style={{minWidth:0}}>
                  <div className="row between">
                    <span className="fw6" style={{fontSize:12.5}}>{r.name}</span>
                    {!r.editable && <span className="pill muted" style={{fontSize:10}}>系统</span>}
                  </div>
                  <span className="t3" style={{fontSize:11}}>{r.scope} · {r.users} 用户</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* 中：权限矩阵 */}
        <div className="card flex1" style={{display:'flex',flexDirection:'column',minWidth:0}}>
          <div className="card-header">
            <div className="col">
              <span className="t3 mono" style={{fontSize:10}}>ROLE_ID · dispatch_lead</span>
              <span className="fw6" style={{fontSize:14, marginTop:2}}>调度组长 · 权限矩阵</span>
            </div>
            <div className="row gap-2">
              <span className="t3 mono" style={{fontSize:11}}>已勾选 27 / 39 项</span>
              <button className="btn sm">复制自其它角色</button>
              <button className="btn primary sm"><Icon name="check" size={11}/>保存</button>
            </div>
          </div>

          <div className="perm-scope">
            <span className="t3 fw5">数据范围</span>
            <div className="seg">
              <button className="seg-item">仅本人</button>
              <button className="seg-item">本机构</button>
              <button className="seg-item active">本机构及下级</button>
              <button className="seg-item">指定客户/网点</button>
              <button className="seg-item">全局</button>
            </div>
          </div>

          <div style={{flex:1, overflow:'auto'}}>
            <table className="table perm-table">
              <thead><tr><th style={{width:140}}>菜单 / 模块</th><th>功能权限（按操作粒度勾选）</th><th style={{width:80}}>菜单可见</th><th style={{width:80}}>批量操作</th></tr></thead>
              <tbody>
                {PERMS.map(m => (
                  <tr key={m.module}>
                    <td className="fw6">{m.module}</td>
                    <td>
                      <div className="perm-chips">
                        {m.perms.map(([p, on], i) => (
                          <span key={i} className={"perm-chip " + (on ? "on" : "off")}>
                            {on && <Icon name="check" size={10}/>}
                            {!on && <Icon name="close" size={10}/>}
                            {p}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td><label className="switch on"><span/></label></td>
                    <td><label className={"switch " + (Math.random() > 0.4 ? "on" : "")}><span/></label></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 机构管理
// ============================================================
function OrgPage() {
  return (
    <PageShell active="org" title="机构管理" breadcrumb={["系统配置", "机构管理"]}
      topRight={<><button className="btn"><Icon name="upload" size={13}/>导出架构</button><button className="btn primary"><Icon name="plus" size={13}/>新增机构</button></>}>
      <div className="org-page">
        <div className="card org-tree" style={{width:340}}>
          <div className="card-header"><span className="card-title">组织架构 · 树视图</span><Icon name="tree" size={13} className="tx"/></div>
          <div style={{padding:'10px 8px'}}>
            <OrgTreeFull/>
          </div>
        </div>

        <div className="card flex1">
          <div className="card-header">
            <div className="col">
              <span className="t3 mono" style={{fontSize:10}}>ORG · jd-ec / dispatch</span>
              <span className="fw6" style={{fontSize:15, marginTop:2}}>京东物流·华东 / 调度部</span>
            </div>
            <div className="row gap-2">
              <button className="btn"><Icon name="edit" size={13}/>编辑</button>
              <button className="btn"><Icon name="trash" size={13}/>删除</button>
            </div>
          </div>

          <div className="org-detail">
            <div className="org-fields">
              <div className="of-cell"><span className="t3">机构编码</span><input className="input" defaultValue="JD-EC-DISPATCH"/></div>
              <div className="of-cell"><span className="t3">机构名称</span><input className="input" defaultValue="调度部"/></div>
              <div className="of-cell"><span className="t3">上级机构</span><input className="input" defaultValue="京东物流·华东"/></div>
              <div className="of-cell"><span className="t3">机构类型</span><select className="input" defaultValue="部门"><option>客户</option><option>分支机构</option><option>部门</option><option>班组</option></select></div>
              <div className="of-cell"><span className="t3">负责人</span><input className="input" defaultValue="沈知行"/></div>
              <div className="of-cell"><span className="t3">联系电话</span><input className="input" defaultValue="189****0421"/></div>
              <div className="of-cell"><span className="t3">数据范围</span><input className="input" defaultValue="本机构及下级"/></div>
              <div className="of-cell"><span className="t3">状态</span><select className="input"><option>启用</option><option>禁用</option></select></div>
              <div className="of-cell" style={{gridColumn:'1 / -1'}}><span className="t3">备注</span><textarea className="input" rows="2" defaultValue="负责亚一中心仓、南区分拨等 5 个网点的调度业务"/></div>
            </div>

            <div className="org-stats">
              <div className="card-header" style={{borderBottom:0,padding:'4px 0'}}><span className="card-title">机构概况</span></div>
              <div className="org-stat-grid">
                <div className="os-cell"><span className="t3">下级机构</span><span className="kpi-value" style={{fontSize:18}}>3</span></div>
                <div className="os-cell"><span className="t3">关联用户</span><span className="kpi-value" style={{fontSize:18}}>28</span></div>
                <div className="os-cell"><span className="t3">绑定角色</span><span className="kpi-value" style={{fontSize:18}}>4</span></div>
                <div className="os-cell"><span className="t3">管辖网点</span><span className="kpi-value" style={{fontSize:18}}>5</span></div>
                <div className="os-cell"><span className="t3">管辖车辆</span><span className="kpi-value" style={{fontSize:18}}>412</span></div>
                <div className="os-cell"><span className="t3">月任务量</span><span className="kpi-value" style={{fontSize:18}}>184k</span></div>
              </div>

              <div className="card-header" style={{borderBottom:0,padding:'12px 0 4px'}}><span className="card-title">直属用户 · 28</span></div>
              <div className="user-strip">
                {USERS.slice(0,7).map((u, i) => (
                  <div key={i} className="us-pill">
                    <div className="ci-avatar sm" style={{background: ['#0090e8','#ff7a3d','#1ce8b5','#9d6dff','#ffb547','#4d8cff','#ff66c4'][i % 7]}}>{u.name[0]}</div>
                    <div className="col"><span className="fw6" style={{fontSize:11.5}}>{u.name}</span><span className="t3" style={{fontSize:10}}>{u.role}</span></div>
                  </div>
                ))}
                <div className="us-pill more">+21</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

function OrgTreeFull() {
  const Row = ({ depth, expand, label, count, type, current }) => (
    <div className={"tree-row " + (current ? "active" : "") + (depth > 0 ? " sub" : "")} style={{paddingLeft: 6 + depth * 16}}>
      {expand !== undefined ? <Icon name={expand ? "chevd" : "chevr"} size={11}/> : <span style={{width:11}}/>}
      <Icon name={type === "company" ? "tree" : type === "client" ? "client" : "users"} size={13} className={current ? "tx" : "t3"}/>
      <span className="flex1" style={{fontSize: depth === 0 ? 12.5 : 12}}>{label}</span>
      <span className="mono t3" style={{fontSize:10}}>{count}</span>
    </div>
  );
  return <>
    <Row depth={0} expand={true} label="无人物流车运营服务" count="142" type="company"/>
      <Row depth={1} expand={true} label="总部" count="34" type="users"/>
        <Row depth={2} label="运营管理部" count="12" type="users"/>
        <Row depth={2} label="数据分析部" count="8" type="users"/>
        <Row depth={2} label="技术支持部" count="14" type="users"/>
      <Row depth={1} expand={true} label="京东物流·华东" count="62" type="client"/>
        <Row depth={2} expand={true} label="调度部" count="28" type="users" current={true}/>
          <Row depth={3} label="日班 A 组" count="14" type="users"/>
          <Row depth={3} label="日班 B 组" count="9" type="users"/>
          <Row depth={3} label="夜班组" count="5" type="users"/>
        <Row depth={2} label="处置部" count="22" type="users"/>
        <Row depth={2} label="运维班组" count="12" type="users"/>
      <Row depth={1} expand={false} label="顺丰速运·上海" count="18" type="client"/>
      <Row depth={1} expand={false} label="中通南方分拨" count="14" type="client"/>
      <Row depth={1} expand={false} label="城北小件中心" count="8" type="client"/>
      <Row depth={1} expand={false} label="美团即时零售" count="5" type="client"/>
      <Row depth={1} expand={false} label="盒马·物流试点" count="1" type="client"/>
  </>;
}

// ============================================================
// PAGE: 字典管理
// ============================================================
const DICTS = [
  { type: "vehicle_status", name: "车辆状态", count: 6, system: true },
  { type: "task_status",    name: "任务状态", count: 7, system: true },
  { type: "alert_level",    name: "告警等级", count: 4, system: true },
  { type: "alert_type",     name: "告警类型", count: 28, system: false },
  { type: "accident_level", name: "事故等级", count: 4, system: false, current: true },
  { type: "site_type",      name: "网点类型", count: 5, system: false },
  { type: "vehicle_brand",  name: "车辆品牌", count: 8, system: false },
  { type: "weather",        name: "天气状况", count: 9, system: false },
  { type: "gender",         name: "性别",     count: 3, system: true },
  { type: "user_status",    name: "用户状态", count: 3, system: true },
];

const DICT_ITEMS = [
  { code: "MINOR",    label: "未遂",    color: "var(--text-3)",   sort: 1, state: "启用", remark: "未发生实际损失" },
  { code: "LIGHT",    label: "轻微",    color: "var(--data-blue)", sort: 2, state: "启用", remark: "财损 < 1000 元" },
  { code: "GENERAL",  label: "一般",    color: "var(--warn)",     sort: 3, state: "启用", remark: "财损 1000-50000 元" },
  { code: "SERIOUS",  label: "严重",    color: "var(--err)",      sort: 4, state: "启用", remark: "人员伤害 / 财损 > 5w" },
];

function DictPage() {
  return (
    <PageShell active="dict" title="字典管理" breadcrumb={["系统配置", "字典管理"]}
      topRight={<><button className="btn"><Icon name="upload" size={13}/>批量导入</button><button className="btn primary"><Icon name="plus" size={13}/>新增字典</button></>}>
      <div className="dict-page">
        <div className="card dict-list">
          <div className="card-header"><span className="card-title">字典类型 · 24</span><input className="input" placeholder="搜索..." style={{width:120}}/></div>
          <div style={{padding:'4px 6px'}}>
            {DICTS.map(d => (
              <div key={d.type} className={"dict-row " + (d.current ? "active" : "")}>
                <Icon name="book" size={13} className={d.current ? "tx" : "t3"}/>
                <div className="col flex1" style={{minWidth:0}}>
                  <div className="row between"><span className="fw6" style={{fontSize:12.5}}>{d.name}</span>{d.system && <span className="pill muted" style={{fontSize:10}}>系统</span>}</div>
                  <span className="t3 mono" style={{fontSize:10}}>{d.type} · {d.count} 项</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="card flex1">
          <div className="card-header">
            <div className="col">
              <span className="t3 mono" style={{fontSize:10}}>DICT_TYPE · accident_level</span>
              <span className="fw6" style={{fontSize:15, marginTop:2}}>事故等级 <span className="t3 fw5" style={{fontSize:12}}>· 4 项</span></span>
            </div>
            <div className="row gap-2">
              <button className="btn"><Icon name="edit" size={13}/>编辑类型</button>
              <button className="btn primary"><Icon name="plus" size={13}/>新增字典项</button>
            </div>
          </div>
          <table className="table">
            <thead><tr><th style={{width:32}}>#</th><th>编码</th><th>显示名</th><th>颜色</th><th>排序</th><th>状态</th><th style={{width:'30%'}}>备注</th><th>引用次数</th><th></th></tr></thead>
            <tbody>
              {DICT_ITEMS.map((d, i) => (
                <tr key={d.code}>
                  <td><div className="step-circle">{i+1}</div></td>
                  <td className="mono fw6">{d.code}</td>
                  <td><span className="pill" style={{color:d.color, background: 'rgba(255,255,255,0.04)', borderColor: d.color}}><span className="dot" style={{background:d.color, boxShadow:`0 0 6px ${d.color}`}}/>{d.label}</span></td>
                  <td><div className="row gap-2"><span className="color-chip" style={{background:d.color}}/><span className="mono t2" style={{fontSize:11}}>{d.color.replace('var(--','').replace(')','')}</span></div></td>
                  <td className="mono">{d.sort}</td>
                  <td><span className="pill ok"><span className="dot"/>{d.state}</span></td>
                  <td className="t2">{d.remark}</td>
                  <td className="mono">{[2,5,18,3][i]}</td>
                  <td><div className="row gap-1"><button className="btn sm ghost"><Icon name="edit" size={12}/></button><button className="btn sm ghost"><Icon name="trash" size={12}/></button></div></td>
                </tr>
              ))}
            </tbody>
          </table>

          <div style={{padding:'12px 16px',borderTop:'1px solid var(--line-1)',background:'var(--bg-3)'}}>
            <div className="row gap-3 t3" style={{fontSize:11.5}}>
              <Icon name="info" size={12}/>
              <span>该字典在 <span className="t1 fw6">事故管理 · 等级筛选</span>、<span className="t1 fw6">事故详情 · 等级标签</span>、<span className="t1 fw6">分析报表 · 事故等级分布</span> 共 3 处使用。修改将实时生效。</span>
            </div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 操作日志
// ============================================================
const OPLOGS = [
  { t: "2026-04-28 10:24:42", user: "沈知行", role: "调度组长", module: "告警处置", action: "认领", target: "AL-2026-0428-007", ip: "10.16.32.87", result: "成功" },
  { t: "2026-04-28 10:23:18", user: "吴桐",   role: "处置员",   module: "任务记录", action: "撤销", target: "T-2026-0428-1180", ip: "10.16.32.92", result: "成功" },
  { t: "2026-04-28 10:18:42", user: "system", role: "系统",     module: "告警处置", action: "派发", target: "AL-2026-0428-005", ip: "—",          result: "成功" },
  { t: "2026-04-28 10:14:08", user: "周野",   role: "处置员",   module: "车辆档案", action: "状态更新", target: "JD-X07-225", ip: "10.16.32.108", result: "成功" },
  { t: "2026-04-28 09:54:52", user: "沈知行", role: "调度组长", module: "任务记录", action: "创建", target: "T-2026-0428-1180", ip: "10.16.32.87", result: "成功" },
  { t: "2026-04-28 09:42:20", user: "linxi",  role: "调度员",   module: "用户管理", action: "禁用", target: "user/142",         ip: "10.16.32.66", result: "失败 · 权限不足" },
  { t: "2026-04-28 09:38:12", user: "赵青远", role: "运营经理", module: "字典管理", action: "新增", target: "alert_type/PEDESTRIAN_NEAR", ip: "10.16.16.4", result: "成功" },
  { t: "2026-04-28 09:32:01", user: "吴桐",   role: "处置员",   module: "事故管理", action: "上传附件", target: "ACC-2026-0408-001 / 现场监控-1.mp4", ip: "10.16.32.92", result: "成功" },
  { t: "2026-04-28 09:14:48", user: "陈书宁", role: "只读分析师", module: "运行监测", action: "导出", target: "今日全平台.xlsx", ip: "10.16.16.118", result: "成功" },
  { t: "2026-04-28 09:08:30", user: "沈知行", role: "调度组长", module: "路线管理", action: "编辑路径", target: "R-04",            ip: "10.16.32.87", result: "成功" },
];

function OpLogPage() {
  return (
    <PageShell active="oplog" title="操作日志" breadcrumb={["审计", "操作日志"]}
      topRight={<><button className="btn"><Icon name="upload" size={13}/>导出</button></>}>
      <div className="info-page">
        <div className="card">
          <Toolbar
            left={<>
              <input className="input" placeholder="操作人 / 目标对象 / IP" style={{width:280}}/>
              <button className="btn sm">今日 ▾</button>
              <button className="btn sm">模块 ▾</button>
              <button className="btn sm">动作 ▾</button>
              <button className="btn sm">结果 ▾</button>
            </>}
            right={<span className="t3 mono" style={{fontSize:11}}>共 4,820 条 / 今日 412</span>}/>
          <table className="table">
            <thead><tr><th>操作时间</th><th>操作人</th><th>角色</th><th>模块</th><th>动作</th><th>目标对象</th><th>IP 地址</th><th>结果</th></tr></thead>
            <tbody>
              {OPLOGS.map((l, i) => (
                <tr key={i}>
                  <td className="mono t2">{l.t}</td>
                  <td>{l.user === 'system' ? <span className="row gap-1 t3 mono"><Icon name="zap" size={11}/>system</span> : <span className="fw6">{l.user}</span>}</td>
                  <td><span className="pill muted">{l.role}</span></td>
                  <td>{l.module}</td>
                  <td><span className={`action-tag action-${l.action.includes('删') || l.action === '禁用' ? 'danger' : l.action === '创建' || l.action === '新增' ? 'create' : 'edit'}`}>{l.action}</span></td>
                  <td className="mono t2" style={{fontSize:11}}>{l.target}</td>
                  <td className="mono t3" style={{fontSize:11}}>{l.ip}</td>
                  <td>{l.result === '成功' ? <span className="pill ok"><span className="dot"/>成功</span> : <span className="pill err"><span className="dot"/>{l.result}</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="pager">
            <span className="t3" style={{fontSize:11}}>显示 1–10 / 共 4,820</span>
            <div className="row gap-1"><button className="btn sm"><Icon name="chevl" size={11}/></button><button className="btn sm primary">1</button><button className="btn sm">2</button><span className="t3">...</span><button className="btn sm">482</button><button className="btn sm"><Icon name="chevr" size={11}/></button></div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

// ============================================================
// PAGE: 登录日志
// ============================================================
const LOGINS = [
  { t: "2026-04-28 10:12:08", user: "吴桐",   ip: "10.16.32.92",  loc: "上海·青浦",  ua: "Chrome 124 · macOS",  result: "成功", session: "1h 12m" },
  { t: "2026-04-28 09:48:42", user: "沈知行", ip: "10.16.32.87",  loc: "上海·青浦",  ua: "Chrome 124 · Windows", result: "成功", session: "在线" },
  { t: "2026-04-28 09:36:18", user: "周野",   ip: "10.16.32.108", loc: "上海·青浦",  ua: "Edge 123 · Windows",   result: "成功", session: "44m" },
  { t: "2026-04-28 09:14:48", user: "陈书宁", ip: "10.16.16.118", loc: "北京·顺义",  ua: "Chrome 124 · macOS",  result: "成功", session: "在线" },
  { t: "2026-04-28 08:42:01", user: "linxi",  ip: "10.16.32.66",  loc: "上海·青浦",  ua: "Chrome 124 · Windows", result: "成功", session: "1h 38m" },
  { t: "2026-04-28 02:08:14", user: "unknown", ip: "182.45.118.42", loc: "未知",     ua: "curl 8.0",            result: "失败 · 用户不存在", session: "—", risk: true },
  { t: "2026-04-28 01:58:32", user: "wangzimeng", ip: "182.45.118.42", loc: "未知",  ua: "curl 8.0",            result: "失败 · 密码错误 (5)", session: "—", risk: true },
  { t: "2026-04-27 22:34:08", user: "赵青远", ip: "10.16.16.4",   loc: "北京·朝阳",  ua: "Safari 17 · iOS",     result: "成功", session: "8m" },
  { t: "2026-04-27 18:32:42", user: "wangzimeng", ip: "112.65.32.18",   loc: "上海·浦东",  ua: "Chrome 124 · Windows", result: "成功", session: "2h 4m" },
];

function LoginLogPage() {
  return (
    <PageShell active="loginlog" title="登录日志" breadcrumb={["审计", "登录日志"]}
      topRight={<>
        <span className="pill err"><span className="dot"/>风险事件 2</span>
        <button className="btn"><Icon name="upload" size={13}/>导出</button>
      </>}>
      <div className="loginlog-page">
        {/* 上：风险态势 */}
        <div className="login-strip">
          <div className="login-cell">
            <span className="t3" style={{fontSize:11}}>今日登录</span>
            <span className="kpi-value" style={{fontSize:22}}>184</span>
            <span className="t3 mono" style={{fontSize:10}}>独立用户 96</span>
          </div>
          <div className="login-cell">
            <span className="t3" style={{fontSize:11}}>当前在线</span>
            <span className="kpi-value tg" style={{fontSize:22}}>32</span>
            <span className="t3 mono" style={{fontSize:10}}>峰值 48</span>
          </div>
          <div className="login-cell">
            <span className="t3" style={{fontSize:11}}>失败登录</span>
            <span className="kpi-value tw" style={{fontSize:22}}>14</span>
            <span className="t3 mono" style={{fontSize:10}}>失败率 7.6%</span>
          </div>
          <div className="login-cell warn">
            <span className="t3" style={{fontSize:11}}>风险事件</span>
            <span className="kpi-value tr" style={{fontSize:22}}>2</span>
            <span className="t3 mono" style={{fontSize:10}}>异地 / 暴力</span>
          </div>
          <div className="login-cell flex1">
            <span className="t3" style={{fontSize:11}}>近 24h 节奏</span>
            <Spark2/>
          </div>
        </div>

        <div className="card">
          <Toolbar
            left={<>
              <input className="input" placeholder="登录人 / IP / 地点" style={{width:280}}/>
              <button className="btn sm">今日 ▾</button>
              <button className="btn sm">结果 ▾</button>
              <button className="btn sm active-filter">仅风险事件</button>
            </>}
            right={<span className="t3 mono" style={{fontSize:11}}>共 1,820 条</span>}/>
          <table className="table">
            <thead><tr><th>登录时间</th><th>登录人</th><th>IP 地址</th><th>地理位置</th><th>设备 / 浏览器</th><th>结果</th><th>会话时长</th><th></th></tr></thead>
            <tbody>
              {LOGINS.map((l, i) => (
                <tr key={i} className={l.risk ? "row-risk" : ""}>
                  <td className="mono t2">{l.t}</td>
                  <td>{l.user === 'unknown' ? <span className="t3 row gap-1"><Icon name="ban" size={11}/>{l.user}</span> : <span className="fw6">{l.user}</span>}</td>
                  <td className="mono t2">{l.ip}</td>
                  <td>{l.loc === '未知' ? <span className="row gap-1 tr"><Icon name="alert" size={11}/>{l.loc}</span> : l.loc}</td>
                  <td className="t2" style={{fontSize:11.5}}>{l.ua}</td>
                  <td>{l.result === '成功' ? <span className="pill ok"><span className="dot"/>成功</span> : <span className="pill err"><span className="dot"/>{l.result}</span>}</td>
                  <td className="mono t2">{l.session === '在线' ? <span className="pill ok" style={{fontSize:10}}><span className="dot"/>在线</span> : l.session}</td>
                  <td><button className="btn sm ghost"><Icon name="more" size={12}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </PageShell>
  );
}

function Spark2() {
  const data = Array.from({length:24}, (_,i) => Math.floor(Math.sin(i/3) * 8 + 14 + Math.random() * 4));
  const max = Math.max(...data);
  return (
    <div style={{display:'flex', gap:2, alignItems:'flex-end', height:36, marginTop:4}}>
      {data.map((v, i) => (
        <div key={i} style={{flex:1, height: `${v/max*100}%`, background:'linear-gradient(180deg, var(--data-cyan), var(--brand-500))', borderRadius:1, boxShadow:'0 0 4px rgba(0,229,255,0.3)'}}/>
      ))}
    </div>
  );
}

// 注册到 window
Object.assign(window, {
  TasksPage, AlertsPage, AccidentPage,
  ClientPage, SitePage, VehiclePage, RoutePage,
  UserPage, RolePage, OrgPage, DictPage,
  OpLogPage, LoginLogPage,
});
