/* global React, ReactDOM, DCArtboard, DCSection, DesignCanvas,
   TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakToggle, TweakSlider,
   MonitorPage, TasksPage, AlertsPage, AccidentPage,
   ClientPage, SitePage, VehiclePage, RoutePage,
   UserPage, RolePage, OrgPage, DictPage, OpLogPage, LoginLogPage */

const { useState: useAS, useEffect: useAE } = React;

// 默认 tweak 值
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "cyan",
  "density": "comfortable",
  "scanline": true
}/*EDITMODE-END*/;

const ACCENT_MAP = {
  cyan:   { c400: "#00e5ff", c500: "#0090e8", c600: "#0078c2" },
  amber:  { c400: "#ffb547", c500: "#ff7a3d", c600: "#d65a1e" },
  violet: { c400: "#b48dff", c500: "#9d6dff", c600: "#7647d8" },
  green:  { c400: "#1ce8b5", c500: "#0ec98c", c600: "#0a9b6c" },
};

function App() {
  const [values, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // 应用 tweak
  useAE(() => {
    const r = document.documentElement;
    const m = ACCENT_MAP[values.accent] || ACCENT_MAP.cyan;
    r.style.setProperty('--brand-400', m.c400);
    r.style.setProperty('--brand-500', m.c500);
    r.style.setProperty('--brand-600', m.c600);
    r.style.setProperty('--data-cyan', m.c400);
    r.style.setProperty('--line-glow', `${m.c400}59`);
    r.classList.toggle('density-compact', values.density === 'compact');
  }, [values]);

  return (
    <>
      <DesignCanvas
        title="无人物流车运营服务平台"
        subtitle="深色科技指挥中心 · 13 个核心页面 · 端到端处置闭环"
        defaultZoom={0.7}>
        <DCSection id="ops" title="① 运营 · 实时指挥与处置闭环">
          <DCArtboard id="monitor" label="01 · 运行监测大屏（首页）" width={1480} height={920}>
            <MonitorPage/>
          </DCArtboard>
          <DCArtboard id="tasks" label="02 · 任务记录 + 任务详情时间轴" width={1480} height={920}>
            <TasksPage/>
          </DCArtboard>
          <DCArtboard id="alerts" label="03 · 告警处置工作流（端到端闭环 + AI 建议）★ 反竞品创新" width={1480} height={1100}>
            <AlertsPage/>
          </DCArtboard>
          <DCArtboard id="accident" label="04 · 事故管理" width={1480} height={920}>
            <AccidentPage/>
          </DCArtboard>
        </DCSection>

        <DCSection id="info" title="② 基础信息 · 客户/网点/车辆/路线">
          <DCArtboard id="client" label="05 · 客户管理（多客户权限隔离 · 左侧组织树）" width={1480} height={820}>
            <ClientPage/>
          </DCArtboard>
          <DCArtboard id="site" label="06 · 网点管理" width={1480} height={820}>
            <SitePage/>
          </DCArtboard>
          <DCArtboard id="vehicle" label="07 · 车辆档案 + 数字孪生卡片 ★ 反竞品创新" width={1480} height={1080}>
            <VehiclePage/>
          </DCArtboard>
          <DCArtboard id="route" label="08 · 路线管理（真实地图 + 站点时刻表）★ 反竞品创新" width={1480} height={1100}>
            <RoutePage/>
          </DCArtboard>
        </DCSection>

        <DCSection id="sys" title="③ 系统配置 · 用户/角色/机构/字典">
          <DCArtboard id="user" label="09 · 用户管理（机构树 + 角色绑定）" width={1480} height={820}>
            <UserPage/>
          </DCArtboard>
          <DCArtboard id="role" label="10 · 角色权限矩阵（操作粒度 + 数据范围）" width={1480} height={920}>
            <RolePage/>
          </DCArtboard>
          <DCArtboard id="org" label="11 · 机构管理（树形架构 + 详情）" width={1480} height={820}>
            <OrgPage/>
          </DCArtboard>
          <DCArtboard id="dict" label="12 · 字典管理（含引用追踪）" width={1480} height={820}>
            <DictPage/>
          </DCArtboard>
        </DCSection>

        <DCSection id="audit" title="④ 审计 · 操作日志 / 登录日志">
          <DCArtboard id="oplog" label="13 · 操作日志" width={1480} height={820}>
            <OpLogPage/>
          </DCArtboard>
          <DCArtboard id="loginlog" label="14 · 登录日志（含风险事件识别）" width={1480} height={820}>
            <LoginLogPage/>
          </DCArtboard>
        </DCSection>
      </DesignCanvas>

      <TweaksPanel title="Tweaks">
        <TweakSection title="主题">
          <TweakRadio
            label="主色调"
            value={values.accent}
            onChange={v => setTweak('accent', v)}
            options={[
              { value: 'cyan',   label: '电光青' },
              { value: 'amber',  label: '物流橙' },
              { value: 'violet', label: '深紫' },
              { value: 'green',  label: '克制绿' },
            ]}/>
        </TweakSection>
        <TweakSection title="布局">
          <TweakRadio
            label="信息密度"
            value={values.density}
            onChange={v => setTweak('density', v)}
            options={[
              { value: 'compact',     label: '紧凑' },
              { value: 'comfortable', label: '舒适' },
            ]}/>
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
