/* global React, Icon */
// ============================================================
// 运行监测大屏 - 指挥中心
// ============================================================

const { useState: useStateMon, useEffect: useEffectMon, useRef: useRefMon } = React;

// ---------- Mock 数据 ----------
const MON_KPIS = [
  { id: "fleet",   label: "全平台车辆",   value: 1284, unit: "台", delta: "+12",  spark: [40,42,45,43,48,52,58,60,62,64,65,66] },
  { id: "online",  label: "在线 / 离线",  value: "1107", sub: "/ 177", unit: "", delta: "在线率 86.2%", spark: [82,84,83,85,86,86,87,86,86,87,86,86], tone: "ok" },
  { id: "active",  label: "活跃网点",     value: 87,   unit: "/ 96",  delta: "9 个静默",  spark: [80,82,84,85,86,87,87,87,87,87,87,87], tone: "info" },
  { id: "tasks",   label: "今日任务",     value: 6420, unit: "单", delta: "已完成 5187",  spark: [200,420,810,1200,1800,2400,3100,3900,4600,5200,5800,6420], tone: "info" },
  { id: "alerts",  label: "今日告警",     value: 23,   unit: "条", delta: "未处置 7",     spark: [1,2,3,4,5,8,11,13,15,17,20,23], tone: "warn" },
  { id: "mileage", label: "累计里程",     value: "284,612", unit: "km", delta: "今日 +1,847", spark: [10,15,22,30,40,52,68,85,108,140,180,220] },
];

const MON_VEHICLES = [
  { id: "JD-X07-118", x: 32, y: 41, status: "moving",   battery: 78, load: 92, route: "R-04", angle: 24 },
  { id: "JD-X07-204", x: 48, y: 35, status: "moving",   battery: 64, load: 100, route: "R-02", angle: 110 },
  { id: "JD-X07-091", x: 56, y: 52, status: "idle",     battery: 91, load: 0,  route: "—",    angle: 0 },
  { id: "JD-X07-156", x: 38, y: 60, status: "moving",   battery: 41, load: 67, route: "R-08", angle: 200 },
  { id: "JD-X07-077", x: 64, y: 28, status: "charging", battery: 32, load: 0,  route: "—",    angle: 0 },
  { id: "JD-X07-312", x: 70, y: 64, status: "moving",   battery: 86, load: 88, route: "R-11", angle: 320 },
  { id: "JD-X07-009", x: 24, y: 70, status: "alert",    battery: 18, load: 54, route: "R-15", angle: 90 },
  { id: "JD-X07-225", x: 44, y: 22, status: "moving",   battery: 72, load: 100, route: "R-02", angle: 60 },
  { id: "JD-X07-188", x: 76, y: 44, status: "idle",     battery: 95, load: 0,  route: "—",    angle: 0 },
  { id: "JD-X07-340", x: 28, y: 28, status: "moving",   battery: 55, load: 75, route: "R-04", angle: 150 },
];

const MON_SITES = [
  { id: "亚一中心仓",   x: 50, y: 48, scale: 14 },
  { id: "南区分拨",     x: 30, y: 64, scale: 9 },
  { id: "东塔配送站",   x: 68, y: 38, scale: 7 },
  { id: "北门枢纽",     x: 42, y: 18, scale: 8 },
  { id: "西区充电场",   x: 64, y: 28, scale: 6 },
];

const MON_ROUTES = [
  { id: "R-04", points: "M 50 48 Q 35 42 32 41 T 28 28", color: "var(--data-cyan)" },
  { id: "R-02", points: "M 50 48 L 44 22 L 48 35", color: "var(--data-violet)" },
  { id: "R-11", points: "M 50 48 Q 58 56 70 64", color: "var(--data-teal)" },
  { id: "R-08", points: "M 50 48 Q 44 56 38 60", color: "var(--data-pink)" },
  { id: "R-15", points: "M 30 64 L 24 70", color: "var(--data-orange)" },
];

const MON_ALERTS = [
  { t: "10:24:18", level: "err",  v: "JD-X07-009", title: "电量过低 18%", site: "南区分拨", who: "未处置" },
  { t: "10:21:02", level: "err",  v: "JD-X07-156", title: "急刹动作触发",  site: "亚一中心仓", who: "未处置" },
  { t: "10:18:44", level: "warn", v: "JD-X07-118", title: "偏离规划路线 12m", site: "亚一中心仓", who: "已派单" },
  { t: "10:14:37", level: "warn", v: "JD-X07-225", title: "前方障碍物滞留 8s", site: "亚一中心仓", who: "已派单" },
  { t: "10:09:55", level: "warn", v: "JD-X07-077", title: "充电功率异常", site: "西区充电场", who: "处置中" },
  { t: "10:02:11", level: "info", v: "JD-X07-340", title: "进入限速区域", site: "亚一中心仓", who: "已忽略" },
  { t: "09:58:43", level: "info", v: "JD-X07-091", title: "传感器回报延迟 1.2s", site: "—", who: "已恢复" },
];

const MON_STATUS_DIST = [
  { label: "运输中", value: 824, color: "var(--data-cyan)" },
  { label: "空闲",   value: 187, color: "var(--data-blue)" },
  { label: "充电中", value: 76,  color: "var(--data-teal)" },
  { label: "维护",   value: 20,  color: "var(--data-amber)" },
  { label: "离线",   value: 177, color: "var(--text-3)" },
];

const MON_TASK_TIMELINE = [
  { hour: "06", planned: 220, done: 218 },
  { hour: "07", planned: 480, done: 472 },
  { hour: "08", planned: 720, done: 706 },
  { hour: "09", planned: 880, done: 851 },
  { hour: "10", planned: 920, done: 760 },
  { hour: "11", planned: 860, done: 0   },
  { hour: "12", planned: 540, done: 0   },
  { hour: "13", planned: 660, done: 0   },
  { hour: "14", planned: 820, done: 0   },
  { hour: "15", planned: 860, done: 0   },
];

const MON_SITE_HEAT = [
  { site: "亚一中心仓",  load: 0.92, tasks: 2840, vehicles: 32 },
  { site: "南区分拨",    load: 0.74, tasks: 1180, vehicles: 14 },
  { site: "东塔配送站",  load: 0.58, tasks: 760,  vehicles: 9  },
  { site: "北门枢纽",    load: 0.46, tasks: 540,  vehicles: 7  },
  { site: "西区充电场",  load: 0.21, tasks: 0,    vehicles: 6  },
  { site: "城北小件中心", load: 0.65, tasks: 920,  vehicles: 11 },
  { site: "运河支线",    load: 0.38, tasks: 280,  vehicles: 4  },
];

// ---------- Sparkline ----------
function Spark({ data, color = "var(--brand-400)", height = 24 }) {
  const max = Math.max(...data), min = Math.min(...data);
  const w = 80, h = height;
  const pts = data.map((v, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((v - min) / Math.max(1, max - min)) * (h - 2) - 1;
    return `${x},${y}`;
  }).join(" ");
  const area = `0,${h} ${pts} ${w},${h}`;
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{display:'block'}}>
      <defs>
        <linearGradient id={`sp-${color}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.35"/>
          <stop offset="100%" stopColor={color} stopOpacity="0"/>
        </linearGradient>
      </defs>
      <polygon points={area} fill={`url(#sp-${color})`}/>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.4"/>
    </svg>
  );
}

// ---------- KPI 卡 ----------
function KpiCard({ k }) {
  const tone = k.tone || "brand";
  const colorMap = { brand: "var(--brand-400)", ok: "var(--ok)", warn: "var(--warn)", err: "var(--err)", info: "var(--data-blue)" };
  return (
    <div className="kpi-card corner">
      <div className="kpi-top">
        <span className="kpi-label">{k.label}</span>
        <span className={`kpi-tone tone-${tone}`}/>
      </div>
      <div className="kpi-mid">
        <span className="kpi-value" style={{fontSize: 28}}>{k.value}</span>
        {k.sub && <span className="kpi-sub mono t3">{k.sub}</span>}
        {k.unit && <span className="kpi-unit t3">{k.unit}</span>}
      </div>
      <div className="kpi-bot">
        <span className="t3" style={{fontSize:11}}>{k.delta}</span>
        <Spark data={k.spark} color={colorMap[tone]}/>
      </div>
    </div>
  );
}

// ---------- 园区地图 ----------
function ParkMap() {
  const [hover, setHover] = useStateMon(null);
  const [tick, setTick] = useStateMon(0);
  useEffectMon(() => {
    const t = setInterval(() => setTick(x => x + 1), 1500);
    return () => clearInterval(t);
  }, []);

  const statusColor = {
    moving: "var(--data-cyan)",
    idle: "var(--data-blue)",
    charging: "var(--data-teal)",
    alert: "var(--err)",
  };

  return (
    <div className="map-wrap">
      {/* Map background */}
      <svg className="map-svg" viewBox="0 0 100 80" preserveAspectRatio="none">
        <defs>
          <pattern id="mapgrid" width="4" height="4" patternUnits="userSpaceOnUse">
            <path d="M 4 0 L 0 0 0 4" fill="none" stroke="rgba(0,229,255,0.05)" strokeWidth="0.1"/>
          </pattern>
          <radialGradient id="mapglow" cx="50%" cy="48%" r="50%">
            <stop offset="0%" stopColor="rgba(0,144,232,0.18)"/>
            <stop offset="100%" stopColor="rgba(0,144,232,0)"/>
          </radialGradient>
          <linearGradient id="rd" x1="0" x2="1">
            <stop offset="0%" stopColor="rgba(255,255,255,0.18)"/>
            <stop offset="50%" stopColor="rgba(255,255,255,0.05)"/>
            <stop offset="100%" stopColor="rgba(255,255,255,0.18)"/>
          </linearGradient>
        </defs>
        <rect width="100" height="80" fill="url(#mapglow)"/>
        <rect width="100" height="80" fill="url(#mapgrid)"/>

        {/* 园区轮廓 (示意建筑/分区) */}
        <g opacity="0.45">
          <rect x="14" y="14" width="20" height="14" fill="rgba(255,255,255,0.025)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.15"/>
          <rect x="40" y="10" width="14" height="10" fill="rgba(255,255,255,0.025)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.15"/>
          <rect x="60" y="18" width="22" height="14" fill="rgba(255,255,255,0.025)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.15"/>
          <rect x="42" y="38" width="20" height="14" fill="rgba(0,144,232,0.07)" stroke="rgba(0,144,232,0.25)" strokeWidth="0.15"/>
          <rect x="20" y="56" width="22" height="14" fill="rgba(255,255,255,0.025)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.15"/>
          <rect x="58" y="56" width="24" height="16" fill="rgba(255,255,255,0.025)" stroke="rgba(255,255,255,0.08)" strokeWidth="0.15"/>
          <rect x="58" y="22" width="14" height="10" fill="rgba(28,232,181,0.06)" stroke="rgba(28,232,181,0.2)" strokeWidth="0.15"/>
        </g>

        {/* 主干道 */}
        <g stroke="url(#rd)" strokeWidth="0.5" fill="none" opacity="0.6">
          <path d="M 5 48 H 95"/>
          <path d="M 50 5 V 75"/>
          <path d="M 5 28 Q 35 32 65 28"/>
          <path d="M 30 75 Q 50 60 70 75"/>
        </g>

        {/* 路线 */}
        {MON_ROUTES.map(r => (
          <path key={r.id} d={r.points} fill="none" stroke={r.color} strokeWidth="0.35"
            strokeDasharray="0.6 0.6" strokeLinecap="round" opacity="0.9"
            style={{animation: 'flow-dash 2s linear infinite'}}/>
        ))}

        {/* 网点 */}
        {MON_SITES.map(s => (
          <g key={s.id} transform={`translate(${s.x} ${s.y})`}>
            <circle r="0.8" fill="rgba(0,229,255,0.15)"/>
            <circle r="0.4" fill="var(--data-cyan)"/>
            <circle r="0.4" fill="var(--data-cyan)" opacity="0.6">
              <animate attributeName="r" from="0.4" to="2.5" dur="2.4s" repeatCount="indefinite"/>
              <animate attributeName="opacity" from="0.6" to="0" dur="2.4s" repeatCount="indefinite"/>
            </circle>
            <text x="1.2" y="0.4" fill="var(--text-2)" fontSize="1.2" fontFamily="var(--font-sans)">{s.id}</text>
          </g>
        ))}

        {/* 车辆 */}
        {MON_VEHICLES.map(v => {
          const c = statusColor[v.status];
          const isAlert = v.status === "alert";
          return (
            <g key={v.id} transform={`translate(${v.x} ${v.y}) rotate(${v.angle})`}
              onMouseEnter={() => setHover(v)} onMouseLeave={() => setHover(null)}
              style={{cursor:'pointer'}}>
              {isAlert && (
                <circle r="2.6" fill="none" stroke={c} strokeWidth="0.18" opacity="0.8">
                  <animate attributeName="r" from="1" to="3.5" dur="1.4s" repeatCount="indefinite"/>
                  <animate attributeName="opacity" from="0.9" to="0" dur="1.4s" repeatCount="indefinite"/>
                </circle>
              )}
              <rect x="-0.8" y="-1.2" width="1.6" height="2.4" rx="0.3" fill={c} opacity="0.95" stroke="rgba(255,255,255,0.4)" strokeWidth="0.08"/>
              <rect x="-0.4" y="-0.9" width="0.8" height="0.5" fill="rgba(0,0,0,0.25)" rx="0.1"/>
            </g>
          );
        })}
      </svg>

      {/* 扫描线 */}
      <div className="map-scan"/>

      {/* 地图叠加 UI */}
      <div className="map-corner tl">
        <div className="row gap-2"><span className="t3 mono" style={{fontSize:10}}>COORD</span><span className="mono t1" style={{fontSize:11}}>31.1942°N · 121.6174°E</span></div>
        <div className="row gap-2"><span className="t3 mono" style={{fontSize:10}}>ZONE</span><span className="mono t1" style={{fontSize:11}}>京东亚一 · 上海青浦</span></div>
      </div>
      <div className="map-corner tr">
        <div className="legend-row">
          <span className="lg-dot" style={{background:'var(--data-cyan)'}}/><span>运输</span>
          <span className="lg-dot" style={{background:'var(--data-blue)'}}/><span>空闲</span>
          <span className="lg-dot" style={{background:'var(--data-teal)'}}/><span>充电</span>
          <span className="lg-dot" style={{background:'var(--err)',boxShadow:'0 0 6px var(--err)'}}/><span>告警</span>
        </div>
      </div>
      <div className="map-corner bl">
        <button className="map-btn"><Icon name="plus" size={11}/></button>
        <button className="map-btn">−</button>
        <button className="map-btn"><Icon name="expand" size={11}/></button>
      </div>
      <div className="map-corner br">
        <span className="t3 mono" style={{fontSize:10}}>SCALE</span>
        <span className="scale-bar"/>
        <span className="mono t2" style={{fontSize:10}}>200m</span>
      </div>

      {/* Hover tooltip */}
      {hover && (
        <div className="map-tip" style={{ left: `${hover.x}%`, top: `${hover.y}%` }}>
          <div className="row between" style={{marginBottom:6}}>
            <span className="mono fw6" style={{fontSize:11}}>{hover.id}</span>
            <span className={`pill ${hover.status === 'alert' ? 'err' : hover.status === 'idle' ? 'info' : 'ok'}`}>
              <span className="dot"/>{hover.status}
            </span>
          </div>
          <div className="tip-grid">
            <div><span className="t3">电量</span><span className="mono">{hover.battery}%</span></div>
            <div><span className="t3">载重</span><span className="mono">{hover.load}%</span></div>
            <div><span className="t3">路线</span><span className="mono">{hover.route}</span></div>
            <div><span className="t3">航向</span><span className="mono">{hover.angle}°</span></div>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- 状态分布环 ----------
function StatusRing() {
  const total = MON_STATUS_DIST.reduce((s, x) => s + x.value, 0);
  let cum = 0;
  const r = 44, c = 2 * Math.PI * r;
  return (
    <div className="ring-wrap">
      <svg viewBox="0 0 120 120" className="ring-svg">
        <circle cx="60" cy="60" r={r} fill="none" stroke="var(--bg-3)" strokeWidth="10"/>
        {MON_STATUS_DIST.map((d, i) => {
          const frac = d.value / total;
          const dash = frac * c;
          const off = -cum * c;
          cum += frac;
          return (
            <circle key={i} cx="60" cy="60" r={r} fill="none"
              stroke={d.color} strokeWidth="10"
              strokeDasharray={`${dash} ${c}`} strokeDashoffset={off}
              transform="rotate(-90 60 60)"/>
          );
        })}
        <text x="60" y="56" textAnchor="middle" fontSize="20" fontWeight="700" fill="var(--text-1)" fontFamily="var(--font-mono)">{total}</text>
        <text x="60" y="72" textAnchor="middle" fontSize="9" fill="var(--text-3)" letterSpacing="2">FLEET</text>
      </svg>
      <div className="ring-legend">
        {MON_STATUS_DIST.map((d, i) => (
          <div key={i} className="ring-row">
            <span className="rd" style={{background: d.color}}/>
            <span className="flex1 t2">{d.label}</span>
            <span className="mono fw6">{d.value}</span>
            <span className="t3 mono" style={{fontSize:11,width:42,textAlign:'right'}}>{(d.value/total*100).toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- 任务时间线 ----------
function TaskTimeline() {
  const max = Math.max(...MON_TASK_TIMELINE.map(d => d.planned));
  const now = 4; // index where "now" is
  return (
    <div className="tl-wrap">
      <div className="tl-bars">
        {MON_TASK_TIMELINE.map((d, i) => {
          const ph = (d.planned / max) * 100;
          const dh = (d.done / max) * 100;
          const isFuture = i > now;
          return (
            <div key={i} className="tl-col">
              <div className="tl-col-bar">
                <div className="tl-bar-planned" style={{height: `${ph}%`, opacity: isFuture ? 0.3 : 0.5}}/>
                {!isFuture && <div className="tl-bar-done" style={{height: `${dh}%`}}/>}
              </div>
              <div className="tl-hour">{d.hour}</div>
            </div>
          );
        })}
        <div className="tl-now-line" style={{left: `${(now + 0.5) / MON_TASK_TIMELINE.length * 100}%`}}>
          <span className="now-pill mono">NOW · 10:24</span>
        </div>
      </div>
      <div className="tl-legend">
        <span className="row gap-1"><span className="lg-bar" style={{background:'var(--brand-400)'}}/>已完成</span>
        <span className="row gap-1"><span className="lg-bar" style={{background:'var(--bg-4)',border:'1px solid var(--line-2)'}}/>计划</span>
      </div>
    </div>
  );
}

// ---------- 网点热力 ----------
function SiteHeat() {
  return (
    <div className="heat-list">
      {MON_SITE_HEAT.map((s, i) => (
        <div key={i} className="heat-row">
          <span className="t1 fw5" style={{fontSize:12,minWidth:96}}>{s.site}</span>
          <div className="heat-bar">
            <div className="heat-bar-fill" style={{
              width: `${s.load * 100}%`,
              background: s.load > 0.8 ? 'linear-gradient(90deg, var(--data-amber), var(--data-orange))'
                       : s.load > 0.5 ? 'linear-gradient(90deg, var(--data-blue), var(--data-cyan))'
                                       : 'linear-gradient(90deg, var(--data-teal), var(--data-cyan))'
            }}/>
          </div>
          <span className="mono t2" style={{fontSize:11, width:48, textAlign:'right'}}>{(s.load*100).toFixed(0)}%</span>
          <span className="mono t3" style={{fontSize:11, width:60, textAlign:'right'}}>{s.tasks}单</span>
          <span className="mono t3" style={{fontSize:11, width:36, textAlign:'right'}}>{s.vehicles}台</span>
        </div>
      ))}
    </div>
  );
}

// ---------- 告警流 ----------
function AlertFeed() {
  return (
    <div className="alert-feed">
      {MON_ALERTS.map((a, i) => (
        <div key={i} className={`alert-row tone-${a.level}`}>
          <span className="alert-dot"/>
          <div className="col flex1" style={{minWidth:0}}>
            <div className="row gap-2 between">
              <span className="mono fw6" style={{fontSize:11}}>{a.v}</span>
              <span className="mono t3" style={{fontSize:10}}>{a.t}</span>
            </div>
            <div className="row gap-2 between" style={{marginTop:2}}>
              <span className="t1" style={{fontSize:12}}>{a.title}</span>
            </div>
            <div className="row gap-2 between" style={{marginTop:2}}>
              <span className="t3" style={{fontSize:11}}>{a.site}</span>
              <span className={`pill ${a.who === '未处置' ? 'err' : a.who === '已派单' || a.who === '处置中' ? 'warn' : 'muted'}`}>{a.who}</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- 整页 ----------
function MonitorPage() {
  const [time, setTime] = useStateMon("");
  useEffectMon(() => {
    const upd = () => {
      const d = new Date();
      const pad = n => String(n).padStart(2,'0');
      setTime(`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`);
    };
    upd();
    const t = setInterval(upd, 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <PageShell active="monitor"
      title="运行监测"
      breadcrumb={["运营", "运行监测"]}
      env="PROD"
      topRight={
        <>
          <div className="seg">
            <button className="seg-item active">园区</button>
            <button className="seg-item">城市</button>
            <button className="seg-item">客户</button>
          </div>
          <div className="seg">
            <button className="seg-item active">实时</button>
            <button className="seg-item">回放</button>
          </div>
          <span className="mono t2" style={{fontSize:11}}>{time}</span>
          <button className="btn"><Icon name="refresh" size={13}/>30s</button>
        </>
      }>
      <div className="mon-page">
        {/* KPI 行 */}
        <div className="mon-kpis">
          {MON_KPIS.map(k => <KpiCard key={k.id} k={k}/>)}
        </div>

        {/* 主栅格：地图 + 右侧三块 */}
        <div className="mon-main">
          <div className="card mon-map-card">
            <div className="card-header">
              <span className="card-title">实时地理态势</span>
              <div className="row gap-2">
                <span className="pill ok"><span className="dot"/>WebSocket 推送中</span>
                <span className="t3" style={{fontSize:11}}>· 上次更新 2s 前</span>
                <button className="btn sm"><Icon name="filter" size={11}/>筛选</button>
                <button className="btn sm"><Icon name="expand" size={11}/></button>
              </div>
            </div>
            <ParkMap/>
          </div>

          <div className="mon-right">
            <div className="card">
              <div className="card-header">
                <span className="card-title">车辆状态分布</span>
                <span className="t3 mono" style={{fontSize:10}}>实时</span>
              </div>
              <div style={{padding:'12px 14px'}}><StatusRing/></div>
            </div>

            <div className="card flex1">
              <div className="card-header">
                <span className="card-title">告警流 · 今日 23 条</span>
                <div className="row gap-2">
                  <span className="pill err"><span className="dot"/>未处置 7</span>
                  <button className="btn sm">全部</button>
                </div>
              </div>
              <AlertFeed/>
            </div>
          </div>
        </div>

        {/* 底部双栏 */}
        <div className="mon-bot">
          <div className="card flex1">
            <div className="card-header">
              <span className="card-title">任务进度时间线</span>
              <div className="row gap-3">
                <span className="t3" style={{fontSize:11}}>计划 6,420 · 已完成 5,187 · 完成率 80.8%</span>
              </div>
            </div>
            <div style={{padding:'14px 16px 8px'}}><TaskTimeline/></div>
          </div>
          <div className="card" style={{flex:'1.2'}}>
            <div className="card-header">
              <span className="card-title">网点活跃度</span>
              <span className="t3" style={{fontSize:11}}>87 / 96 · 9 个静默</span>
            </div>
            <div style={{padding:'10px 14px'}}><SiteHeat/></div>
          </div>
        </div>
      </div>
    </PageShell>
  );
}

window.MonitorPage = MonitorPage;
