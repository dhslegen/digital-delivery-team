/* global React */
// ============================================================
// 共享 chrome 与基础组件
// ============================================================

const { useState, useEffect, useRef, useMemo } = React;

// -------- ICON 系统（线性图标，统一 1.5px 描边）--------
function Icon({ name, size = 16, className = "", style = {} }) {
  const s = { width: size, height: size, ...style };
  const p = {
    width: size, height: size, viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round",
    className, style: s,
  };
  switch (name) {
    case "monitor": return <svg {...p}><path d="M3 5h18v11H3z"/><path d="M8 20h8M12 16v4"/><circle cx="7" cy="9" r="1"/><path d="M10 11l3-3 3 4 2-2"/></svg>;
    case "tasks":   return <svg {...p}><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h10M7 17h6"/></svg>;
    case "alert":   return <svg {...p}><path d="M12 3l9 16H3z"/><path d="M12 10v4M12 17v.5"/></svg>;
    case "accident":return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M9 9l6 6M15 9l-6 6"/></svg>;
    case "info":    return <svg {...p}><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 3v18"/></svg>;
    case "users":   return <svg {...p}><circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="9" r="2"/><path d="M21 18c0-2.5-1.8-4.3-4-4.5"/></svg>;
    case "shield":  return <svg {...p}><path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/></svg>;
    case "tree":    return <svg {...p}><rect x="3" y="3" width="6" height="6" rx="1"/><rect x="15" y="9" width="6" height="6" rx="1"/><rect x="3" y="15" width="6" height="6" rx="1"/><path d="M9 6h3v9M12 12h3"/></svg>;
    case "book":    return <svg {...p}><path d="M4 4h12a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M4 4v12a4 4 0 0 1 4-4h12"/></svg>;
    case "log":     return <svg {...p}><path d="M5 4h11l4 4v12H5z"/><path d="M16 4v4h4M9 12h6M9 16h6M9 8h2"/></svg>;
    case "login":   return <svg {...p}><path d="M14 4h5v16h-5"/><path d="M3 12h12M11 8l4 4-4 4"/></svg>;
    case "vehicle": return <svg {...p}><path d="M3 14V9l3-4h12l3 5v4"/><path d="M3 14h18v4H3z"/><circle cx="7.5" cy="18" r="1.5"/><circle cx="16.5" cy="18" r="1.5"/></svg>;
    case "site":    return <svg {...p}><path d="M12 2C8 2 5 5 5 9c0 5 7 13 7 13s7-8 7-13c0-4-3-7-7-7z"/><circle cx="12" cy="9" r="2.5"/></svg>;
    case "client":  return <svg {...p}><path d="M3 21V8l5-4 5 4v13M13 12h8v9h-8M16 16h2M16 19h2M7 13h2M7 17h2"/></svg>;
    case "route":   return <svg {...p}><circle cx="6" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="M8 6h6a4 4 0 0 1 4 4v6"/><path d="M14 8l-2-2 2-2M18 14l-2 2 2 2" opacity=".4"/></svg>;
    case "search":  return <svg {...p}><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>;
    case "filter":  return <svg {...p}><path d="M3 5h18l-7 9v6l-4-2v-4z"/></svg>;
    case "plus":    return <svg {...p}><path d="M12 5v14M5 12h14"/></svg>;
    case "edit":    return <svg {...p}><path d="M4 20h4l10-10-4-4L4 16z"/><path d="M14 6l4 4"/></svg>;
    case "trash":   return <svg {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>;
    case "more":    return <svg {...p}><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>;
    case "chevd":   return <svg {...p}><path d="M6 9l6 6 6-6"/></svg>;
    case "chevr":   return <svg {...p}><path d="M9 6l6 6-6 6"/></svg>;
    case "chevl":   return <svg {...p}><path d="M15 6l-6 6 6 6"/></svg>;
    case "close":   return <svg {...p}><path d="M6 6l12 12M18 6L6 18"/></svg>;
    case "check":   return <svg {...p}><path d="M5 12l5 5 9-11"/></svg>;
    case "bell":    return <svg {...p}><path d="M6 16V11a6 6 0 1 1 12 0v5l1.5 2H4.5z"/><path d="M10 20a2 2 0 0 0 4 0"/></svg>;
    case "settings":return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a7.97 7.97 0 0 0 0-6l2-1.5-2-3.4-2.4 1A8 8 0 0 0 12 3l-1-2H9l-1 2a8 8 0 0 0-5 2.1l-2.4-1-2 3.4L.6 9a7.97 7.97 0 0 0 0 6L-1.4 16.5l2 3.4 2.4-1A8 8 0 0 0 9 21l1 2h2l1-2a8 8 0 0 0 5-2.1l2.4 1 2-3.4z" transform="translate(2)"/></svg>;
    case "zap":     return <svg {...p}><path d="M13 3L4 14h7l-1 7 9-11h-7z"/></svg>;
    case "globe":   return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18"/></svg>;
    case "command": return <svg {...p}><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/></svg>;
    case "battery": return <svg {...p}><rect x="2" y="7" width="18" height="10" rx="2"/><path d="M22 11v2"/><rect x="4" y="9" width="10" height="6" rx="1" fill="currentColor" opacity=".6"/></svg>;
    case "speed":   return <svg {...p}><path d="M12 14a8 8 0 0 1 8-8M12 14a8 8 0 0 0-8-8"/><circle cx="12" cy="14" r="1.5"/><path d="M13 13l4-4"/><path d="M4 18h16"/></svg>;
    case "signal":  return <svg {...p}><path d="M3 19h2v-3H3zM8 19h2v-7H8zM13 19h2v-11h-2zM18 19h2V4h-2z"/></svg>;
    case "play":    return <svg {...p}><path d="M6 4l14 8-14 8z" fill="currentColor"/></svg>;
    case "pause":   return <svg {...p}><rect x="6" y="4" width="4" height="16" fill="currentColor"/><rect x="14" y="4" width="4" height="16" fill="currentColor"/></svg>;
    case "refresh": return <svg {...p}><path d="M3 12a9 9 0 0 1 15-6.7L21 8M21 4v4h-4M21 12a9 9 0 0 1-15 6.7L3 16M3 20v-4h4"/></svg>;
    case "expand":  return <svg {...p}><path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/></svg>;
    case "history": return <svg {...p}><path d="M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 8v4l3 2"/></svg>;
    case "upload":  return <svg {...p}><path d="M4 16v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3M12 4v12M7 9l5-5 5 5"/></svg>;
    case "doc":     return <svg {...p}><path d="M5 3h10l4 4v14H5z"/><path d="M15 3v4h4M9 13h6M9 17h4M9 9h2"/></svg>;
    case "key":     return <svg {...p}><circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/></svg>;
    case "ban":     return <svg {...p}><circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/></svg>;
    case "wifi":    return <svg {...p}><path d="M3 9a14 14 0 0 1 18 0M6 13a9 9 0 0 1 12 0M9 17a4 4 0 0 1 6 0"/><circle cx="12" cy="20" r="0.5" fill="currentColor"/></svg>;
    case "temp":    return <svg {...p}><path d="M10 14V5a2 2 0 1 1 4 0v9a4 4 0 1 1-4 0z"/><circle cx="12" cy="16" r="1.5" fill="currentColor"/></svg>;
    case "camera":  return <svg {...p}><rect x="3" y="6" width="18" height="14" rx="2"/><circle cx="12" cy="13" r="4"/><path d="M8 6l2-2h4l2 2"/></svg>;
    case "lidar":   return <svg {...p}><circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>;
    case "package": return <svg {...p}><path d="M12 3l9 5v8l-9 5-9-5V8z"/><path d="M3 8l9 5 9-5M12 13v9"/></svg>;
    case "logo":    return <svg {...p}><path d="M3 17l9-12 9 12M7 17h10l-5-7z" fill="currentColor"/></svg>;
    default: return <svg {...p}><rect x="3" y="3" width="18" height="18" rx="2"/></svg>;
  }
}

// -------- 侧栏导航 --------
const NAV = [
  { group: "运营", items: [
    { id: "monitor",  label: "运行监测", icon: "monitor", badge: "LIVE" },
    { id: "tasks",    label: "任务记录", icon: "tasks" },
    { id: "alerts",   label: "告警处置", icon: "alert", count: 7 },
    { id: "accident", label: "事故管理", icon: "accident" },
  ]},
  { group: "基础信息", items: [
    { id: "client",  label: "客户管理", icon: "client" },
    { id: "site",    label: "网点管理", icon: "site" },
    { id: "vehicle", label: "车辆档案", icon: "vehicle" },
    { id: "route",   label: "路线管理", icon: "route" },
  ]},
  { group: "系统配置", items: [
    { id: "user",  label: "用户管理", icon: "users" },
    { id: "role",  label: "角色权限", icon: "shield" },
    { id: "org",   label: "机构管理", icon: "tree" },
    { id: "dict",  label: "字典管理", icon: "book" },
  ]},
  { group: "审计", items: [
    { id: "oplog",    label: "操作日志", icon: "log" },
    { id: "loginlog", label: "登录日志", icon: "login" },
  ]},
];

function Sidebar({ active = "monitor" }) {
  return (
    <aside className="sidebar">
      <div className="sb-brand">
        <div className="sb-logo"><Icon name="logo" size={18}/></div>
        <div className="col" style={{lineHeight: 1.15}}>
          <div className="fw7" style={{fontSize:13,letterSpacing:'.02em'}}>无人物流车</div>
          <div className="t3 mono" style={{fontSize:10,letterSpacing:'.12em'}}>OPS · 智驭中枢</div>
        </div>
      </div>

      <div className="sb-search">
        <Icon name="search" size={13}/>
        <input placeholder="搜索车辆 / 任务 / 客户..."/>
        <span className="kbd">⌘K</span>
      </div>

      {NAV.map(group => (
        <div className="sb-group" key={group.group}>
          <div className="sb-group-title">{group.group}</div>
          {group.items.map(it => (
            <a key={it.id} className={"sb-item" + (it.id === active ? " active" : "")}>
              <Icon name={it.icon} size={15}/>
              <span className="flex1">{it.label}</span>
              {it.badge && <span className="sb-badge live">{it.badge}</span>}
              {it.count && <span className="sb-badge num">{it.count}</span>}
            </a>
          ))}
        </div>
      ))}

      <div className="sb-foot">
        <div className="sb-user">
          <div className="avatar">沈</div>
          <div className="col flex1" style={{lineHeight:1.2}}>
            <div className="fw6" style={{fontSize:12}}>沈知行</div>
            <div className="t3" style={{fontSize:11}}>京东物流 · 调度组长</div>
          </div>
          <Icon name="chevd" size={14}/>
        </div>
      </div>
    </aside>
  );
}

// -------- 顶栏 --------
function Topbar({ title, breadcrumb = [], right, env = "PROD" }) {
  return (
    <div className="topbar">
      <div className="row gap-3 flex1">
        <div className="col" style={{lineHeight:1.2}}>
          <div className="row gap-2 t3" style={{fontSize:11}}>
            {breadcrumb.map((b,i) => (
              <React.Fragment key={i}>
                <span>{b}</span>
                {i < breadcrumb.length-1 && <Icon name="chevr" size={10}/>}
              </React.Fragment>
            ))}
          </div>
          <div className="fw6" style={{fontSize:15,marginTop:2}}>{title}</div>
        </div>
      </div>
      <div className="row gap-2">
        {right}
        <div className="env-pill">
          <span className="dot"/>
          <span className="mono" style={{fontSize:10}}>{env}</span>
        </div>
        <button className="btn icon ghost"><Icon name="bell" size={15}/></button>
        <button className="btn icon ghost"><Icon name="settings" size={15}/></button>
      </div>
    </div>
  );
}

// -------- Artboard chrome (page wrapper) --------
function PageShell({ active, title, breadcrumb, topRight, env, children }) {
  return (
    <div className="app-shell">
      <Sidebar active={active}/>
      <div className="app-main">
        <Topbar title={title} breadcrumb={breadcrumb} right={topRight} env={env}/>
        <div className="app-body">{children}</div>
      </div>
    </div>
  );
}

window.Icon = Icon;
window.Sidebar = Sidebar;
window.Topbar = Topbar;
window.PageShell = PageShell;
