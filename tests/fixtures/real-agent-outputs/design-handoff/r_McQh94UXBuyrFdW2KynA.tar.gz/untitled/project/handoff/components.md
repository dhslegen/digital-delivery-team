# 组件清单（设计稿 → React 组件 → AntD 映射）

> 每一行 = 一个可复用组件。**直接用左列名字命名 React 文件**，避免不同人起不同名。

---

## 一、Shell（页面外壳，全局共用）

| 组件名 | 设计稿位置 | AntD 基底 | 备注 |
|---|---|---|---|
| `<AppShell>` | 整体 | `Layout` | 总入口，组合 Sidebar + Topbar + Outlet |
| `<Sidebar>` | 左侧 240px | `Menu` (mode=inline) | 4 大模块：运营/基础信息/系统配置/审计 |
| `<Topbar>` | 顶栏 56px | `Layout.Header` 自绘 | 含面包屑 / 全局搜索 / 告警铃铛 / 用户菜单 |
| `<Breadcrumb>` | 顶栏左 | `Breadcrumb` | 自动从 router meta 生成 |
| `<NotificationBell>` | 顶栏右 | `Badge + Popover` | 红点数 = 未读告警，点开看最新 5 条 |
| `<UserMenu>` | 顶栏右 | `Dropdown` | 个人中心 / 切换语言 / 退出 |
| `<PageShell>` | 单页面包装 | – | 提供标题 / 面包屑 / Action 区 / 内容区 |
| `<Icon name="..."/>` | 全局 | – | 1.5px 描边图标系统，名字见 `shell.jsx` |

---

## 二、Common（业务无关原子组件）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<KpiCard>` | – | 大屏 KPI 卡片，含数字 + 趋势 + sparkline |
| `<StatusPill>` | `Tag` | 状态标签（带颜色点） |
| `<Toolbar>` | – | 表格上方工具条（搜索/筛选/导出） |
| `<Pager>` | `Pagination` | 表格下方分页 |
| `<Sparkline>` | – | 微缩趋势图（24h、48 数据点） |
| `<RingProgress>` | `Progress` (type=circle) | 环形百分比 |
| `<TimeAgo>` | – | "3 分钟前"，自动刷新 |
| `<EmptyState>` | `Empty` | 空状态（4 种：无数据 / 搜索无结果 / 无权限 / 出错） |
| `<ErrorBoundary>` | – | React 错误兜底 |
| `<Skeleton>` | `Skeleton` | 加载骨架 |
| `<TabBar>` | `Tabs` | 卡片内嵌 tab |
| `<Switch>` | `Switch` | 自绘小开关（设计稿专用） |

---

## 三、Monitor（运行监测大屏 P0）

| 组件名 | 第三方 | 用途 |
|---|---|---|
| `<MonitorMap>` | 高德 JSAPI 2.0 | 全屏地图，含车辆/网点/路线图层 |
| `<VehicleLayer>` | 高德 + react-amap | 车辆点位实时刷新（WS） |
| `<HeatmapLayer>` | 高德 | 热点区域（可关） |
| `<KpiStrip>` | – | 顶部 8 个 KPI 横条 |
| `<AlertFeed>` | – | 右侧告警瀑布流（自动滚动 + 暂停） |
| `<TaskGantt>` | 自绘 | 底部任务进度横条（按车辆分行） |
| `<MonitorTimeline>` | – | 24h 任务密度时间轴 |

---

## 四、Task（任务管理 P1）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<TaskTable>` | `Table` | 任务列表（虚拟滚动） |
| `<TaskFilters>` | `Form + DatePicker.RangePicker` | 任务筛选条 |
| `<TaskDetailDrawer>` | `Drawer` | 任务详情抽屉（768px 宽） |
| `<TaskRouteMini>` | – | 任务起点→终点的路线缩略图 |
| `<TaskTimeline>` | – | 时间轴事件流（5 种 tone：info/ok/warn/err/muted） |
| `<TaskActions>` | `Button.Group` | 派发 / 暂停 / 取消按钮组 |
| `<DispatchModal>` | `Modal + Select` | 派发车辆选择器 |

---

## 五、Alert（告警处置工作流 P0 ★）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<AlertQueue>` | `List` | 左侧告警队列（按 level 排序） |
| `<AlertDetail>` | – | 右侧详情主区 |
| `<WorkflowStages>` | `Steps` 自绘 | 5 段工作流条（received → closed） |
| `<AISuggestionCard>` | – | AI 建议卡（首选建议高亮 + 一键执行） |
| `<DispatchTimeline>` | – | 处置日志时间轴 |
| `<AlertActionsBar>` | – | 底部固定 Action 区（分派/处置/转事故/关闭） |
| `<HandleActionModal>` | `Modal` | 处置动作配置（远程降速参数等） |

---

## 六、Accident（事故管理 P1）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<AccidentTable>` | `Table` | 事故列表 |
| `<AccidentDetail>` | – | 详情主体 |
| `<AccidentMeta>` | `Descriptions` | 事故元信息（2 列） |
| `<AttachmentGrid>` | `Image.PreviewGroup` | 附件网格 |
| `<ResolutionLog>` | – | 处理过程时间轴 |
| `<TransitionModal>` | `Modal` | 状态扭转弹窗 |

---

## 七、Vehicle / Route / Client / Site（基础信息 P1）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<VehicleTable>` | `Table` | 车辆列表（左半屏） |
| `<VehicleTwinCard>` | Three.js + R3F | **数字孪生**：3D 车辆 + 实时遥测 |
| `<TelemetryStrip>` | – | 6 格遥测数据 |
| `<VehicleArchive>` | `Descriptions` | 车辆档案 |
| `<RouteList>` | `List` | 路线列表 |
| `<RouteEditor>` | 高德绘制 + 自绘表单 | 路径编辑 + 站点编辑 |
| `<RouteSchedule>` | – | 时刻表编辑 |
| `<ClientOrgTree>` | `Tree` | 客户组织树 |
| `<SiteMap>` | 高德 | 网点地图 |

---

## 八、System（用户/角色/机构/字典 P2）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<UserTable>` | `Table` | 用户列表 |
| `<UserEditDrawer>` | `Drawer + Form` | 用户编辑（角色多选、机构选择） |
| `<RoleList>` | `List` | 角色列表（左侧） |
| `<PermissionMatrix>` | – | **权限矩阵**：模块 × 操作（核心组件） |
| `<DataScopeEditor>` | – | 数据范围编辑（全部/本机构/自定义） |
| `<OrgTree>` | `Tree` | 机构树（含拖拽排序） |
| `<OrgDetailForm>` | `Form` | 机构详情表单 |
| `<DictTypeList>` | `List` | 字典类型 |
| `<DictItemTable>` | `Table` | 字典项（含颜色/引用数） |

---

## 九、Audit（日志 P2）

| 组件名 | AntD 基底 | 用途 |
|---|---|---|
| `<OpLogTable>` | `Table` | 操作日志（含 action 标签着色） |
| `<LoginLogTable>` | `Table` | 登录日志（风险事件高亮行） |
| `<RiskHighlight>` | – | 异地/暴力破解的红色行包装器 |

---

## 十、第三方依赖明细

```json
{
  "antd":                    "^5.18",
  "@ant-design/icons":       "^5.3",
  "react":                   "^18.3",
  "react-dom":               "^18.3",
  "react-router-dom":        "^6.23",
  "@tanstack/react-query":   "^5.45",
  "zustand":                 "^4.5",
  "@xstate/react":           "^4.1",
  "xstate":                  "^5.13",
  "react-hook-form":         "^7.51",
  "zod":                     "^3.23",
  "dayjs":                   "^1.11",
  "echarts":                 "^5.5",
  "echarts-for-react":       "^3.0",
  "three":                   "^0.165",
  "@react-three/fiber":      "^8.16",
  "@react-three/drei":       "^9.108",
  "mqtt":                    "^5.7",
  "react-amap":              "^2.0",
  "lodash-es":               "^4.17",
  "classnames":              "^2.5"
}
```
