/**
 * types.ts — 核心数据模型 / 枚举 / 字段命名
 *
 * ⚠️ 这是前后端的字段共识；任何字段调整必须双方同意并改这份文件。
 * ⚠️ UI 显示文案在组件内写，本文件只定义英文 key + 字面量类型。
 */

// ============================================================
// 通用
// ============================================================

export interface PageQuery {
  page: number;       // 1-based
  pageSize: number;   // 默认 20
  keyword?: string;
  sort?: string;      // e.g. "createdAt:desc"
  filters?: Record<string, string | number | boolean | string[]>;
}

export interface PageResult<T> {
  total: number;
  page: number;
  pageSize: number;
  list: T[];
}

export interface AuditFields {
  createdAt: string;     // ISO 8601
  createdBy: string;     // userId
  createdByName?: string;
  updatedAt: string;
  updatedBy: string;
  updatedByName?: string;
}

export type ID = string;

// ============================================================
// 车辆
// ============================================================

export type VehicleStatus =
  | 'running'    // 运行中
  | 'idle'       // 待命
  | 'charging'   // 充电中
  | 'offline'    // 离线
  | 'fault'      // 故障
  | 'maintenance'; // 维保中

export type VehicleModel = 'X3' | 'X3-Plus' | 'L4-City' | 'L4-Park';

export interface Vehicle extends AuditFields {
  id: ID;
  plateNo: string;            // 车牌
  model: VehicleModel;
  vin: string;
  status: VehicleStatus;
  siteId: ID;                 // 归属网点
  clientId: ID;               // 归属客户
  currentTaskId?: ID;
  currentRouteId?: ID;
  battery: number;            // 0-100
  speed: number;              // km/h
  signal: number;             // 0-5
  position: GeoPoint;
  heading: number;            // 0-360
  odometer: number;           // 总里程 km
  firmware: string;
  lastReportAt: string;
  faultCount24h: number;
}

export interface GeoPoint {
  lng: number;
  lat: number;
}

// ============================================================
// 任务
// ============================================================

export type TaskStatus =
  | 'pending'      // 待派发
  | 'dispatched'   // 已派发
  | 'running'      // 执行中
  | 'paused'       // 暂停
  | 'completed'    // 已完成
  | 'failed'       // 失败
  | 'cancelled';   // 已取消

export type TaskType =
  | 'delivery'     // 配送
  | 'pickup'       // 揽件
  | 'transfer'     // 园区中转
  | 'return';      // 退回

export interface Task extends AuditFields {
  id: ID;
  taskNo: string;             // 业务单号 e.g. T20260507-0042
  type: TaskType;
  status: TaskStatus;
  vehicleId: ID;
  vehiclePlate?: string;
  routeId: ID;
  routeName?: string;
  clientId: ID;
  origin: TaskWaypoint;
  destination: TaskWaypoint;
  cargo: CargoInfo;
  plannedStartAt: string;
  plannedEndAt: string;
  actualStartAt?: string;
  actualEndAt?: string;
  progress: number;           // 0-100
  events: TaskEvent[];
}

export interface TaskWaypoint {
  siteId?: ID;
  name: string;
  address: string;
  position: GeoPoint;
  contact?: string;
  phone?: string;
}

export interface CargoInfo {
  name: string;
  weight: number;             // kg
  volume?: number;            // m³
  count: number;
  remark?: string;
}

export interface TaskEvent {
  id: ID;
  taskId: ID;
  at: string;
  type: 'created' | 'dispatched' | 'started' | 'arrived' | 'departed' | 'paused' | 'resumed' | 'completed' | 'alert' | 'note';
  tone: 'info' | 'ok' | 'warn' | 'err' | 'muted';
  text: string;
  operator?: string;
  payload?: Record<string, unknown>;
}

// ============================================================
// 告警
// ============================================================

export type AlertLevel = 'critical' | 'warning' | 'info';

export type AlertCategory =
  | 'collision'         // 碰撞预警
  | 'lowBattery'        // 低电量
  | 'offRoute'          // 偏离路线
  | 'connectionLost'    // 通讯中断
  | 'sensorFault'       // 传感器故障
  | 'overTime'          // 任务超时
  | 'manualIntervene'   // 人工介入
  | 'geoFenceBreak';    // 越界

export type AlertWorkflowStage =
  | 'received'    // 接收
  | 'assigned'    // 分派
  | 'handling'    // 处置中
  | 'verified'    // 已核实
  | 'closed';     // 已闭环

export interface Alert extends AuditFields {
  id: ID;
  alertNo: string;            // A20260507-001
  level: AlertLevel;
  category: AlertCategory;
  title: string;
  description: string;
  vehicleId: ID;
  vehiclePlate?: string;
  taskId?: ID;
  position?: GeoPoint;
  occurredAt: string;
  stage: AlertWorkflowStage;
  assigneeId?: ID;
  assigneeName?: string;
  resolution?: string;
  closedAt?: string;
  aiSuggestions: AISuggestion[];   // ★ 反竞品创新点
  dispatchLog: DispatchLogItem[];
  attachments: Attachment[];
}

export interface AISuggestion {
  id: ID;
  confidence: number;          // 0-1
  action: string;              // e.g. "远程降速至 5km/h 并通知最近运维人员"
  reasoning: string;
  primary: boolean;            // 是否首选建议
}

export interface DispatchLogItem {
  at: string;
  by: string;
  action: string;
  payload?: Record<string, unknown>;
}

export interface Attachment {
  id: ID;
  type: 'image' | 'video' | 'log' | 'pdf';
  name: string;
  url: string;
  size: number;
  thumbnailUrl?: string;
}

// ============================================================
// 事故
// ============================================================

export type AccidentSeverity = 'minor' | 'moderate' | 'major' | 'severe';

export type AccidentStatus =
  | 'reported'         // 已上报
  | 'investigating'    // 调查中
  | 'pendingResponsibility' // 责任认定中
  | 'compensating'     // 理赔中
  | 'closed';          // 已结案

export interface Accident extends AuditFields {
  id: ID;
  accidentNo: string;
  occurredAt: string;
  severity: AccidentSeverity;
  status: AccidentStatus;
  vehicleId: ID;
  taskId?: ID;
  position: GeoPoint;
  locationDesc: string;
  description: string;
  responsibility?: 'us' | 'thirdParty' | 'shared' | 'undetermined';
  injuries: number;
  propertyDamage: number;     // 人民币，元
  insuranceClaimNo?: string;
  resolutions: AccidentResolution[];
  attachments: Attachment[];
}

export interface AccidentResolution {
  at: string;
  by: string;
  type: 'investigate' | 'arbitrate' | 'compensate' | 'note';
  text: string;
}

// ============================================================
// 客户 / 网点 / 路线
// ============================================================

export interface Client extends AuditFields {
  id: ID;
  name: string;
  shortName?: string;
  industry: string;
  contractNo: string;
  contractStartAt: string;
  contractEndAt: string;
  status: 'active' | 'paused' | 'expired';
  contact: string;
  phone: string;
  vehicleCount: number;
  siteCount: number;
}

export interface Site extends AuditFields {
  id: ID;
  clientId: ID;
  name: string;
  type: 'park' | 'warehouse' | 'station' | 'depot';
  position: GeoPoint;
  address: string;
  manager: string;
  phone: string;
  vehicleCount: number;
}

export interface Route extends AuditFields {
  id: ID;
  name: string;
  clientId: ID;
  siteId: ID;
  type: 'fixed' | 'flexible';
  status: 'active' | 'inactive';
  totalDistance: number;       // km
  estimatedDuration: number;   // 分钟
  waypoints: RouteWaypoint[];
  schedule?: RouteSchedule;
}

export interface RouteWaypoint {
  id: ID;
  index: number;
  type: 'origin' | 'stop' | 'destination';
  name: string;
  address: string;
  position: GeoPoint;
  dwellTime: number;           // 停留分钟
  scheduledTime?: string;      // HH:mm
}

export interface RouteSchedule {
  type: 'daily' | 'weekly' | 'cron';
  startAt: string;
  intervalMinutes?: number;
  cronExpression?: string;
}

// ============================================================
// 用户 / 角色 / 机构 / 字典
// ============================================================

export interface User extends AuditFields {
  id: ID;
  username: string;
  realName: string;
  email: string;
  phone: string;
  avatar?: string;
  orgId: ID;
  orgName?: string;
  roleIds: ID[];
  status: 'active' | 'disabled' | 'locked';
  lastLoginAt?: string;
}

export interface Role extends AuditFields {
  id: ID;
  code: string;                 // ROLE_ADMIN
  name: string;
  description?: string;
  permissions: Permission[];
  dataScope: DataScope;
  userCount: number;
}

export interface Permission {
  key: string;                  // 'monitor:view' | 'task:dispatch' | ...
  module: string;
  actions: PermissionAction[];
}

export type PermissionAction = 'view' | 'create' | 'edit' | 'delete' | 'export' | 'dispatch' | 'approve';

export type DataScope =
  | { type: 'all' }
  | { type: 'org', orgIds: ID[], includeChildren: boolean }
  | { type: 'self' }
  | { type: 'custom', clientIds?: ID[], siteIds?: ID[] };

export interface Org extends AuditFields {
  id: ID;
  parentId?: ID;
  code: string;
  name: string;
  type: 'company' | 'department' | 'team';
  manager?: string;
  phone?: string;
  sort: number;
  userCount: number;
  children?: Org[];
}

export interface DictType {
  id: ID;
  code: string;                 // 'vehicle_status'
  name: string;
  description?: string;
  itemCount: number;
}

export interface DictItem extends AuditFields {
  id: ID;
  typeCode: string;
  label: string;
  value: string;
  color?: string;               // 状态色
  icon?: string;
  sort: number;
  remark?: string;
  refCount: number;             // 被引用次数
}

// ============================================================
// 日志
// ============================================================

export interface OpLog {
  id: ID;
  at: string;
  userId: ID;
  userName: string;
  action: 'create' | 'edit' | 'delete' | 'export' | 'login' | 'dispatch' | 'approve';
  module: string;
  target: string;               // 操作对象描述
  targetId?: ID;
  ip: string;
  userAgent: string;
  result: 'success' | 'failed';
  duration: number;             // ms
  payload?: Record<string, unknown>;
}

export interface LoginLog {
  id: ID;
  at: string;
  userId?: ID;                  // 失败可能未知
  userName: string;
  ip: string;
  location: string;
  userAgent: string;
  result: 'success' | 'wrongPassword' | 'locked' | 'expired' | 'unknown';
  sessionDuration?: number;     // 秒；'在线' = -1
  isRiskEvent: boolean;
  riskReason?: '异地登录' | '暴力破解' | '异常时段' | '设备异常';
}

// ============================================================
// 实时（WebSocket / MQTT）
// ============================================================

export type RealtimeChannel =
  | 'alerts'        // 告警流
  | 'telemetry'     // 车辆遥测
  | 'taskEvents'    // 任务事件
  | 'kpi';          // 大屏 KPI

export interface RealtimeMessage<T = unknown> {
  channel: RealtimeChannel;
  ts: string;
  type: string;
  data: T;
}

export interface VehicleTelemetry {
  vehicleId: ID;
  position: GeoPoint;
  heading: number;
  speed: number;
  battery: number;
  signal: number;
  status: VehicleStatus;
  ts: string;
}
