# 路由表 + 权限点

> 给前端 React Router 6 配置用，也给后端校验权限用。
> **每个 path 必须有 permission**，否则前端不渲染、后端不放行。

---

## 路由清单

| Path | 页面文件 | 权限点 | Sidebar 分组 | 备注 |
|---|---|---|---|---|
| `/` | – | – | – | 重定向到 `/monitor` |
| `/login` | `pages/login` | – | 不显示 | 登录页 |
| `/monitor` | `pages/monitor` | `monitor:view` | 运营 | **首页：运行监测大屏** |
| `/tasks` | `pages/tasks/list` | `task:view` | 运营 | 任务列表 |
| `/tasks/:id` | `pages/tasks/detail` | `task:view` | 运营 | 任务详情 |
| `/alerts` | `pages/alerts/workflow` | `alert:view` | 运营 | 告警处置工作流 ★ |
| `/alerts/:id` | `pages/alerts/workflow` | `alert:view` | 运营 | 选中具体告警 |
| `/accidents` | `pages/accidents/list` | `accident:view` | 运营 | 事故列表 |
| `/accidents/:id` | `pages/accidents/detail` | `accident:view` | 运营 | 事故详情 |
| `/info/clients` | `pages/info/clients` | `client:view` | 基础信息 | 客户管理 |
| `/info/sites` | `pages/info/sites` | `site:view` | 基础信息 | 网点管理 |
| `/info/vehicles` | `pages/info/vehicles` | `vehicle:view` | 基础信息 | 车辆档案（含数字孪生） |
| `/info/vehicles/:id` | `pages/info/vehicles/detail` | `vehicle:view` | 基础信息 | 车辆详情 |
| `/info/routes` | `pages/info/routes` | `route:view` | 基础信息 | 路线管理 |
| `/system/users` | `pages/system/users` | `user:view` | 系统配置 | 用户管理 |
| `/system/roles` | `pages/system/roles` | `role:view` | 系统配置 | 角色权限 |
| `/system/orgs` | `pages/system/orgs` | `org:view` | 系统配置 | 机构管理 |
| `/system/dicts` | `pages/system/dicts` | `dict:view` | 系统配置 | 字典管理 |
| `/audit/operations` | `pages/audit/operations` | `log:operation:view` | 审计 | 操作日志 |
| `/audit/logins` | `pages/audit/logins` | `log:login:view` | 审计 | 登录日志 |
| `/profile` | `pages/profile` | – | 不显示 | 个人中心 |
| `/403` | `pages/error/403` | – | 不显示 | 无权限 |
| `/404` | `pages/error/404` | – | 不显示 | 找不到 |
| `/500` | `pages/error/500` | – | 不显示 | 服务异常 |

---

## 权限点完整列表

按 `module:action` 命名。`*` 通配。

```
monitor:view                  # 大屏

task:view  task:create  task:edit  task:dispatch  task:cancel  task:export
alert:view  alert:assign  alert:handle  alert:close  alert:export
accident:view  accident:create  accident:edit  accident:transition  accident:close
vehicle:view  vehicle:create  vehicle:edit  vehicle:delete
route:view  route:create  route:edit  route:delete
client:view  client:create  client:edit  client:delete
site:view  site:create  site:edit  site:delete

user:view  user:create  user:edit  user:delete  user:resetPassword  user:enable
role:view  role:create  role:edit  role:delete  role:assignPermission
org:view  org:create  org:edit  org:delete
dict:view  dict:create  dict:edit  dict:delete

log:operation:view  log:operation:export
log:login:view  log:login:export
```

---

## React Router 配置样例

```tsx
import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AppShell } from '@/components/shell/AppShell';
import { RequirePermission } from '@/components/auth/RequirePermission';

export const router = createBrowserRouter([
  { path: '/login', lazy: () => import('@/pages/login') },
  {
    path: '/',
    element: <AppShell />,
    children: [
      { index: true, element: <Navigate to="/monitor" replace /> },
      {
        path: 'monitor',
        element: <RequirePermission perm="monitor:view" />,
        children: [{ index: true, lazy: () => import('@/pages/monitor') }],
      },
      // ...
    ],
  },
  { path: '/403', lazy: () => import('@/pages/error/403') },
  { path: '/404', lazy: () => import('@/pages/error/404') },
  { path: '*', element: <Navigate to="/404" replace /> },
]);
```

---

## Sidebar 菜单配置（与上表 1:1）

```ts
export const SIDEBAR_MENU = [
  {
    group: '运营',
    items: [
      { key: 'monitor',   path: '/monitor',   label: '运行监测', icon: 'monitor',  perm: 'monitor:view' },
      { key: 'tasks',     path: '/tasks',     label: '任务记录', icon: 'tasks',    perm: 'task:view' },
      { key: 'alerts',    path: '/alerts',    label: '告警处置', icon: 'alert',    perm: 'alert:view' },
      { key: 'accidents', path: '/accidents', label: '事故管理', icon: 'accident', perm: 'accident:view' },
    ],
  },
  {
    group: '基础信息',
    items: [
      { key: 'clients',  path: '/info/clients',  label: '客户管理', icon: 'client',  perm: 'client:view' },
      { key: 'sites',    path: '/info/sites',    label: '网点管理', icon: 'site',    perm: 'site:view' },
      { key: 'vehicles', path: '/info/vehicles', label: '车辆档案', icon: 'vehicle', perm: 'vehicle:view' },
      { key: 'routes',   path: '/info/routes',   label: '路线管理', icon: 'route',   perm: 'route:view' },
    ],
  },
  {
    group: '系统配置',
    items: [
      { key: 'users', path: '/system/users', label: '用户管理', icon: 'users',    perm: 'user:view' },
      { key: 'roles', path: '/system/roles', label: '角色权限', icon: 'shield',   perm: 'role:view' },
      { key: 'orgs',  path: '/system/orgs',  label: '机构管理', icon: 'tree',     perm: 'org:view' },
      { key: 'dicts', path: '/system/dicts', label: '字典管理', icon: 'book',     perm: 'dict:view' },
    ],
  },
  {
    group: '审计',
    items: [
      { key: 'oplog',    path: '/audit/operations', label: '操作日志', icon: 'log',   perm: 'log:operation:view' },
      { key: 'loginlog', path: '/audit/logins',     label: '登录日志', icon: 'login', perm: 'log:login:view' },
    ],
  },
];
```
