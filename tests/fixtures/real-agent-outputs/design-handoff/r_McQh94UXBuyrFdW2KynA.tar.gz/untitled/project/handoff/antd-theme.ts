/**
 * antd-theme.ts
 * Ant Design 5 主题配置 — 已与设计 token 对齐
 *
 * 用法：
 *   import { ConfigProvider } from 'antd';
 *   import { darkTheme } from './antd-theme';
 *
 *   <ConfigProvider theme={darkTheme} locale={zhCN}>
 *     <App />
 *   </ConfigProvider>
 */

import { theme, type ThemeConfig } from 'antd';
import tokens from './tokens.json';

// 取色辅助
const c = (path: string): string => {
  const parts = path.split('.');
  let v: any = tokens.color;
  for (const p of parts) v = v[p];
  return v.value;
};

export const darkTheme: ThemeConfig = {
  algorithm: theme.darkAlgorithm,
  token: {
    // ---- 颜色 ----
    colorPrimary:        c('brand.500'),
    colorInfo:           c('status.info'),
    colorSuccess:        c('status.ok'),
    colorWarning:        c('status.warn'),
    colorError:          c('status.err'),

    colorBgBase:         c('bg.1'),
    colorBgContainer:    c('bg.2'),
    colorBgElevated:     c('bg.3'),
    colorBgLayout:       c('bg.1'),
    colorBgSpotlight:    c('bg.4'),

    colorBorder:         c('line.1'),
    colorBorderSecondary:c('line.2'),

    colorText:           c('text.1'),
    colorTextSecondary:  c('text.2'),
    colorTextTertiary:   c('text.3'),
    colorTextQuaternary: c('text.4'),

    // ---- 字体 ----
    fontFamily:     "Inter, 'PingFang SC', 'Microsoft YaHei', system-ui, sans-serif",
    fontFamilyCode: "'JetBrains Mono', 'SF Mono', Consolas, monospace",
    fontSize:       12,
    fontSizeSM:     11,
    fontSizeLG:     14,
    fontSizeXL:     16,
    fontSizeHeading1: 28,
    fontSizeHeading2: 22,
    fontSizeHeading3: 18,
    fontSizeHeading4: 16,
    fontSizeHeading5: 14,
    lineHeight:     1.55,

    // ---- 圆角 ----
    borderRadius:   6,
    borderRadiusSM: 4,
    borderRadiusLG: 10,
    borderRadiusXS: 3,

    // ---- 间距 ----
    paddingXS: 8,
    paddingSM: 12,
    padding:   16,
    paddingLG: 20,
    marginXS:  8,
    marginSM:  12,
    margin:    16,

    // ---- 控件高度 ----
    controlHeightSM: 24,
    controlHeight:   30,
    controlHeightLG: 36,

    // ---- 阴影 ----
    boxShadow:          '0 4px 16px rgba(0,0,0,0.5)',
    boxShadowSecondary: '0 1px 2px rgba(0,0,0,0.4)',

    // ---- 动效 ----
    motionDurationFast: '120ms',
    motionDurationMid:  '200ms',
    motionDurationSlow: '320ms',
    motionEaseInOut:    'cubic-bezier(0.2, 0.8, 0.2, 1)',

    // ---- 线宽 ----
    lineWidth: 1,
    lineWidthBold: 1.5,

    // ---- 滚动条 ----
    wireframe: false,
  },
  components: {
    Layout: {
      bodyBg:        c('bg.1'),
      headerBg:      c('bg.2'),
      siderBg:       c('bg.2'),
      headerHeight:  56,
    },
    Menu: {
      darkItemBg:           'transparent',
      darkItemSelectedBg:   'linear-gradient(90deg, rgba(0,144,232,0.18), transparent)' as any,
      darkItemSelectedColor: c('text.1'),
      darkItemHoverBg:      'rgba(255,255,255,0.04)',
      darkSubMenuItemBg:    'transparent',
      itemHeight:           36,
      itemMarginInline:     6,
    },
    Button: {
      defaultBg:     c('bg.3'),
      defaultColor:  c('text.1'),
      defaultBorderColor: c('line.2'),
      primaryShadow: '0 0 18px rgba(0,229,255,0.35)',
      borderRadius:  6,
      controlHeight: 30,
    },
    Table: {
      headerBg:        c('bg.3'),
      headerColor:     c('text.3'),
      rowHoverBg:      'rgba(255,255,255,0.02)',
      borderColor:     c('line.1'),
      cellPaddingBlock: 11,
      cellPaddingInline: 12,
      headerSplitColor: 'transparent',
    },
    Tabs: {
      itemActiveColor:  c('brand.400'),
      itemSelectedColor: c('brand.400'),
      inkBarColor:      c('brand.400'),
      itemHoverColor:   c('text.1'),
      titleFontSize:    12,
    },
    Tag: {
      defaultBg: c('bg.3'),
      borderRadiusSM: 3,
    },
    Input: {
      activeBorderColor:  c('brand.400'),
      hoverBorderColor:   c('line.3'),
      activeShadow:       '0 0 0 2px rgba(0,229,255,0.15)',
    },
    Select: {
      optionSelectedBg: 'rgba(0,144,232,0.18)',
    },
    Modal: {
      contentBg: c('bg.2'),
      headerBg:  c('bg.2'),
      titleColor: c('text.1'),
    },
    Drawer: {
      colorBgElevated: c('bg.2'),
    },
    Tooltip: {
      colorBgSpotlight: c('bg.4'),
      colorTextLightSolid: c('text.1'),
    },
    Dropdown: {
      controlItemBgHover: 'rgba(255,255,255,0.04)',
    },
    Tree: {
      directoryNodeSelectedBg: 'linear-gradient(90deg, rgba(0,144,232,0.18), transparent)' as any,
      nodeSelectedBg:          'linear-gradient(90deg, rgba(0,144,232,0.18), transparent)' as any,
      nodeHoverBg:             'rgba(255,255,255,0.04)',
    },
    Card: {
      colorBgContainer: c('bg.2'),
      headerBg:         c('bg.2'),
      headerHeight:     40,
    },
    Badge: {
      statusSize: 6,
    },
    Form: {
      labelColor:       c('text.2'),
      labelRequiredMarkColor: c('status.err'),
      verticalLabelPadding: '0 0 4px',
    },
  },
};

export default darkTheme;
