# 状态机：任务 / 告警 / 事故

> 三个核心实体的状态流转。**前后端必须严格遵守**，禁止跳过状态。
> 推荐前端用 [XState](https://stately.ai) 实现，避免 if/else 蔓延。

---

## 一、任务（Task）

### 1.1 状态枚举

| code | 中文 | 含义 |
|---|---|---|
| `pending` | 待派发 | 已创建，未指定车辆 |
| `dispatched` | 已派发 | 已绑定车辆，未发车 |
| `running` | 执行中 | 车辆已离开起点 |
| `paused` | 暂停 | 因故障 / 告警 / 人工暂停 |
| `completed` | 已完成 | 终点签收 |
| `failed` | 失败 | 多次重试仍未送达 |
| `cancelled` | 已取消 | 人工取消 |

### 1.2 流转图

```
        ┌──────────┐
  ─────▶│ pending  │──cancel──▶ cancelled
        └────┬─────┘
             │ dispatch
             ▼
        ┌──────────┐
        │dispatched│──cancel──▶ cancelled
        └────┬─────┘
             │ start
             ▼
        ┌──────────┐  pause   ┌────────┐
        │ running  │◀────────▶│ paused │
        └────┬──┬──┘  resume  └───┬────┘
             │  │                 │
     finish  │  │ alert/timeout    │ giveUp
             ▼  ▼                 ▼
        ┌────────┐         ┌──────────┐
        │completed│         │  failed  │
        └────────┘         └──────────┘
```

### 1.3 转换矩阵

| from \ to | pending | dispatched | running | paused | completed | failed | cancelled |
|---|---|---|---|---|---|---|---|
| pending | – | ✅ dispatch | – | – | – | – | ✅ cancel |
| dispatched | ↩ unbind | – | ✅ start | – | – | – | ✅ cancel |
| running | – | – | – | ✅ pause | ✅ finish | ✅ fail | – |
| paused | – | – | ✅ resume | – | – | ✅ giveUp | – |
| completed | – | – | – | – | – | – | – |
| failed | – | – | – | – | – | – | – |
| cancelled | – | – | – | – | – | – | – |

---

## 二、告警（Alert）★ 端到端处置闭环

### 2.1 状态枚举

| code | 中文 | 含义 |
|---|---|---|
| `received` | 已接收 | 系统收到告警 |
| `assigned` | 已分派 | 指定运维人员 |
| `handling` | 处置中 | 已采取行动（远程降速/通知/...） |
| `verified` | 已核实 | 处置结果确认 |
| `closed` | 已闭环 | 归档；可写入 KB |

### 2.2 流转图（含 AI 自动化分支）

```
                     [告警进入]
                         │
                         ▼
                  ┌──────────────┐
                  │  received    │
                  └──────┬───────┘
                         │
              ┌──────────┴──────────┐
        AI auto-assign          人工 assign
              ▼                     ▼
                  ┌──────────────┐
                  │  assigned    │
                  └──────┬───────┘
                         │ handle (执行 AI 建议 / 人工动作)
                         ▼
                  ┌──────────────┐  retry
                  │  handling    │◀──────┐
                  └──────┬───────┘       │
                         │ verify        │
                         ▼               │
                  ┌──────────────┐       │
                  │  verified    │───────┘ rehandle
                  └──────┬───────┘
                         │ close
                         ▼
                  ┌──────────────┐
                  │  closed      │
                  └──────────────┘
```

### 2.3 反竞品差异点

- **AI 建议在 `received → assigned` 之间生成**（异步），界面用「AI 推荐 ✦」标识。
- 一键执行 AI 首选建议会同时完成 `assign + handle`，**两步合一**。
- `handling → closed` 必填 `resolution`，沉淀进知识库供下次相同场景调用。

---

## 三、事故（Accident）

### 3.1 状态枚举

| code | 中文 | 含义 |
|---|---|---|
| `reported` | 已上报 | 告警升级或人工上报 |
| `investigating` | 调查中 | 现场取证 |
| `pendingResponsibility` | 责任认定中 | 多方介入 |
| `compensating` | 理赔中 | 已认责，走理赔 |
| `closed` | 已结案 | 终态 |

### 3.2 流转图

```
   [告警升级 / 人工上报]
            │
            ▼
     ┌──────────────┐
     │  reported    │
     └──────┬───────┘
            │ startInvestigate
            ▼
     ┌──────────────┐
     │investigating │
     └──────┬───────┘
            │ submitFinding
            ▼
     ┌──────────────────────┐
     │pendingResponsibility │
     └──────┬───────────────┘
            │ adjudicate
            ▼
     ┌──────────────┐
     │ compensating │
     └──────┬───────┘
            │ close
            ▼
     ┌──────────────┐
     │   closed     │
     └──────────────┘
```

### 3.3 关联

- 一个事故可以由多个告警**升级合并**而来 → `accident.relatedAlertIds: ID[]`
- 事故关联的任务自动转为 `failed` 并写明原因。

---

## 四、XState 实现样例（前端）

```ts
import { createMachine } from 'xstate';
import type { TaskStatus } from '@/types';

export const taskMachine = createMachine({
  id: 'task',
  initial: 'pending' as TaskStatus,
  states: {
    pending:    { on: { DISPATCH: 'dispatched', CANCEL: 'cancelled' } },
    dispatched: { on: { START: 'running', UNBIND: 'pending', CANCEL: 'cancelled' } },
    running:    { on: { PAUSE: 'paused', FINISH: 'completed', FAIL: 'failed' } },
    paused:     { on: { RESUME: 'running', GIVE_UP: 'failed' } },
    completed:  { type: 'final' },
    failed:     { type: 'final' },
    cancelled:  { type: 'final' },
  },
});
```

后端在每个 transition endpoint（如 `POST /tasks/{id}/dispatch`）也用同样的状态机校验。
