# 无人物流车运营服务平台 — 前端 Handoff 包

> 设计交付：**14 个核心页面 / 4 个模块 / 完整设计 token**
> 目标：让前端 1:1 还原设计稿，并保持 token、数据、状态、API 四个维度的可维护性。

---

## 一、目录索引

| 文件 | 用途 | 给谁 |
|---|---|---|
| `README.md` | 总览、技术栈、协作流程 | 全员 |
| `tokens.json` | 设计变量（颜色/字号/间距/阴影） | 前端 / 设计 |
| `antd-theme.ts` | Ant Design 5 主题配置（已映射好 token） | 前端 |
| `types.ts` | 核心数据模型 / 枚举 / 字段命名 | 前后端 |
| `api-contract.yaml` | OpenAPI 3.0 接口草稿（REST + WebSocket） | 前后端 |
| `state-machines.md` | 任务 / 告警 / 事故状态流转图 | 前后端 / PM |
| `components.md` | 组件清单（设计稿 → React 组件 → AntD 映射） | 前端 |
| `routes.md` | 路由表 + 权限点 | 前端 |
| `index.html` | 本 Handoff 包的可视化索引页（点链接看每份文档） | 全员 |

---

## 二、技术栈（推荐）

```
React 18 + TypeScript + Vite
├── UI:     Ant Design 5 (深色主题，token 全量覆盖)
├── 路由:   React Router 6
├── 状态:   Zustand + TanStack Query (v5)
├── 实时:   WebSocket (告警流) + MQTT.js (车辆遥测)
├── 地图:   高德 JSAPI 2.0  ← 中国大陆首选
├── 图表:   ECharts 5
├── 3D:     Three.js + @react-three/fiber (车辆数字孪生)
├── 表单:   react-hook-form + zod
└── 工具:   dayjs · lodash-es · classnames
```

---

## 三、目录结构建议

```
src/
├── design-tokens/
│   ├── tokens.css         ← 复制自设计稿
│   ├── tokens.json        ← 本 Handoff 提供
│   └── antd-theme.ts      ← 本 Handoff 提供
├── api/
│   ├── client.ts          ← axios + interceptor
│   ├── ws.ts              ← WebSocket 复用器
│   └── modules/           ← 按业务模块拆分
├── stores/                ← Zustand store
├── components/
│   ├── shell/             ← Sidebar / Topbar / PageShell（直接复用设计稿）
│   ├── monitor/           ← 大屏专用
│   ├── alert/             ← 告警工作流
│   └── common/            ← KPI / Pill / Toolbar / Sparkline
├── pages/                 ← 14 个路由页面
├── types/                 ← 复制自 types.ts
└── utils/
```

---

## 四、协作流程

### 4.1 Token 同步
设计修改 `tokens.css` → 跑 `pnpm tokens:gen` → 自动产出 `tokens.ts` + `antd-theme.ts` 增量更新。**禁止前端硬编码颜色**，所有色值必须来自 token。

### 4.2 字段命名
- 中文显示文案：在组件里写
- 英文 key：**严格遵守 `types.ts`**，前后端共用
- 例：状态字段 → `vehicleStatus: 'running' | 'idle' | 'charging' | 'offline' | 'fault'`，UI 上展示「运行中 / 待命 / 充电中 / 离线 / 故障」

### 4.3 接口联调
1. 后端先按 `api-contract.yaml` 起 mock（推荐 [Apifox](https://apifox.com)）
2. 前端用 mock 跑通页面
3. 后端实现真接口，字段不一致以 yaml 为准
4. 任何字段调整 → 改 yaml → 改 types.ts → 双方拉同步

### 4.4 状态机
任务 / 告警 / 事故的状态扭转**必须**走 `state-machines.md` 定义的流转，前端推荐用 [XState](https://stately.ai) 实现，避免 if/else 蔓延。

---

## 五、交付里程碑

| 阶段 | 周数 | 交付 | 验收人 |
|---|---|---|---|
| W1 | 项目脚手架 + Shell + Token 全量接入 | 顶栏 / 侧栏 / 路由可点 | 设计 |
| W2-3 | P0：监测大屏 + 告警工作流 | 端到端处置闭环可演示 | PM |
| W4-5 | P1：任务 / 事故 / 车辆档案 / 路线 | CRUD 完整 + 数字孪生 | PM |
| W6 | P2：用户 / 角色 / 机构 / 字典 / 日志 | 全功能 | PM |
| W7 | 联调 + 还原度 review + 性能压测 | 设计 review + 1万条数据流畅 | 设计 + PM |

---

## 六、还原度红线

- **像素**：±2px 内
- **颜色**：必须来自 token，不允许 `#xxx` 硬编码
- **字体**：标题 = Inter / PingFang SC，数据 = JetBrains Mono
- **间距**：使用 `--s-1 ~ --s-8` token，禁止魔法数字
- **图标**：1.5px 描边，统一来源（设计提供 `shell.jsx` 内 Icon 组件，照抄即可）
- **空/错/加载态**：每个页面都要有，由前端负责，设计配合 review

---

## 七、问题反馈

任何字段不清楚、状态流转不确定、视觉细节有疑问，一律 **先在群里 @设计 / @后端**，禁止自行决定。
